# ══════════════════════════════════════════════════════
#  socket_server.py — Module ①: Nhận packet gộp từ RPi
#  Port 5000 | RPi gửi: enc + imu + laser(8 hướng) + bat
# ══════════════════════════════════════════════════════
import socket
import threading
import json
import logging
from config import SERVER_IP, SERVER_PORT, BUFFER_SIZE, CLIENT_TIMEOUT, NUM_LASERS
from shared_state import (data_queue, connection_lock, connected_clients,
                           set_latest_laser, set_rpi_conn)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [SERVER] %(message)s",
    datefmt="%H:%M:%S"
)

REQUIRED_FIELDS = {"ts", "enc", "imu"}


def validate_packet(data: dict) -> bool:
    if not REQUIRED_FIELDS.issubset(data.keys()):
        return False
    if "l" not in data["enc"] or "r" not in data["enc"]:
        return False
    if "gz" not in data["imu"]:
        return False
    if "laser" in data and len(data["laser"]) != NUM_LASERS:
        return False
    return True


def handle_client(conn: socket.socket, addr: tuple):
    """
    Đọc liên tục từ TCP stream, tách packet bằng '\\n'.
    Dùng buffer tích lũy để không bỏ sót packet nào.
    """
    logging.info(f"RPi kết nối: {addr}")
    with connection_lock:
        connected_clients[addr] = threading.current_thread()
    set_rpi_conn(conn)

    buf = ""
    conn.settimeout(CLIENT_TIMEOUT)

    try:
        while True:
            try:
                chunk = conn.recv(BUFFER_SIZE)
            except socket.timeout:
                logging.warning("RPi timeout — không nhận được dữ liệu")
                break
            if not chunk:
                break

            buf += chunk.decode("utf-8", errors="ignore")

            # Xử lý tất cả packet đầy đủ trong buffer
            while "\n" in buf:
                line, buf = buf.split("\n", 1)
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                except json.JSONDecodeError as e:
                    logging.warning(f"JSON lỗi từ {addr}: {e}")
                    continue

                if not validate_packet(data):
                    logging.warning(f"Packet thiếu/sai field: {list(data.keys())}")
                    continue

                if "laser" in data:
                    set_latest_laser(data["ts"], data["laser"])

                try:
                    data_queue.put_nowait(data)
                except Exception:
                    logging.warning("data_queue đầy — bỏ 1 packet")

    except Exception as e:
        logging.error(f"Lỗi kết nối {addr}: {e}")
    finally:
        conn.close()
        with connection_lock:
            connected_clients.pop(addr, None)
        set_rpi_conn(None)
        logging.info(f"RPi ngắt kết nối: {addr}")


def start_server():
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind((SERVER_IP, SERVER_PORT))
    srv.listen(5)
    logging.info(f"Server lắng nghe {SERVER_IP}:{SERVER_PORT}")
    try:
        while True:
            conn, addr = srv.accept()
            threading.Thread(
                target=handle_client, args=(conn, addr), daemon=True
            ).start()
    except KeyboardInterrupt:
        logging.info("Server dừng.")
    finally:
        srv.close()
