# ══════════════════════════════════════════════════════
#  gui/control_panel.py — Panel trạng thái + điều khiển
# ══════════════════════════════════════════════════════
import math
import time
import threading
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout,
                              QLabel, QPushButton, QLineEdit,
                              QGroupBox, QTextEdit, QGridLayout)
from PyQt5.QtCore    import Qt, QTimer
from PyQt5.QtGui     import QFont
from shared_state    import get_pose, get_ctrl_state, get_path
from path_planner    import plan
from controller      import emergency_stop


class ControlPanel(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedWidth(220)
        self._build_ui()
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._refresh)
        self._timer.start(200)   # 5 Hz

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(8)

        # ── Trạng thái ────────────────────────────────
        grp = QGroupBox("Trạng thái robot")
        g   = QGridLayout(grp)
        g.setSpacing(4)

        self._lbl_state = QLabel("IDLE")
        self._lbl_state.setAlignment(Qt.AlignCenter)
        self._lbl_state.setStyleSheet(
            "font-weight:500;padding:3px;border-radius:6px;"
            "background:#f1efe8;color:#5f5e5a;font-size:12px"
        )
        g.addWidget(self._lbl_state, 0, 0, 1, 2)

        fields = [
            ("x (m)",  "_lbl_x"), ("y (m)",   "_lbl_y"),
            ("θ (°)",  "_lbl_t"), ("Pin (V)", "_lbl_bat"),
            ("v (m/s)","_lbl_v"), ("w (r/s)", "_lbl_w"),
        ]
        for i, (key, attr) in enumerate(fields):
            row, col = divmod(i, 2)
            box = QWidget()
            box.setStyleSheet("background:#f1efe8;border-radius:6px")
            bl  = QVBoxLayout(box)
            bl.setContentsMargins(4, 4, 4, 4)
            bl.setSpacing(2)
            lk = QLabel(key)
            lk.setStyleSheet("font-size:10px;color:#888780")
            lv = QLabel("—")
            lv.setStyleSheet("font-size:13px;font-weight:500")
            bl.addWidget(lk)
            bl.addWidget(lv)
            setattr(self, attr, lv)
            g.addWidget(box, row + 1, col)

        layout.addWidget(grp)

        # ── Đặt goal ──────────────────────────────────
        grp2 = QGroupBox("Đặt goal")
        gl   = QVBoxLayout(grp2)
        gl.setSpacing(6)

        row_xy = QHBoxLayout()
        self._inp_x = QLineEdit("2.0"); self._inp_x.setPlaceholderText("X (m)")
        self._inp_y = QLineEdit("1.0"); self._inp_y.setPlaceholderText("Y (m)")
        row_xy.addWidget(self._inp_x)
        row_xy.addWidget(self._inp_y)
        gl.addLayout(row_xy)

        btn_plan = QPushButton("Plan ↗")
        btn_plan.setStyleSheet(
            "background:#eeedfe;color:#3c3489;"
            "border:0.5px solid #afa9ec;border-radius:6px;"
            "padding:5px;font-weight:500"
        )
        btn_plan.clicked.connect(self._on_plan)
        gl.addWidget(btn_plan)

        btn_rp = QPushButton("Re-plan")
        btn_rp.clicked.connect(self._on_replan)
        gl.addWidget(btn_rp)

        btn_stop = QPushButton("⬛  EMERGENCY STOP")
        btn_stop.setStyleSheet(
            "background:#fcebeb;color:#a32d2d;"
            "border:0.5px solid #f09595;border-radius:6px;"
            "padding:6px;font-weight:500"
        )
        btn_stop.clicked.connect(self._on_stop)
        gl.addWidget(btn_stop)

        layout.addWidget(grp2)

        # ── Log ───────────────────────────────────────
        grp3 = QGroupBox("Log")
        ll   = QVBoxLayout(grp3)
        self._log = QTextEdit()
        self._log.setReadOnly(True)
        self._log.setFont(QFont("Courier", 9))
        self._log.setMaximumHeight(130)
        ll.addWidget(self._log)
        layout.addWidget(grp3)
        layout.addStretch()

    # ── Slots ─────────────────────────────────────────
    def _on_plan(self):
        try:
            gx = float(self._inp_x.text())
            gy = float(self._inp_y.text())
            self.append_log(f"Planning → ({gx:.2f}, {gy:.2f})", "info")
            threading.Thread(target=plan, args=(gx, gy), daemon=True).start()
        except ValueError:
            self.append_log("Goal không hợp lệ!", "warn")

    def _on_replan(self):
        path = get_path()
        if path:
            gx, gy = path[-1]
            self._inp_x.setText(f"{gx:.2f}")
            self._inp_y.setText(f"{gy:.2f}")
            self._on_plan()
        else:
            self.append_log("Chưa có goal để re-plan", "warn")

    def _on_stop(self):
        emergency_stop()
        self.append_log("EMERGENCY STOP!", "warn")

    def set_goal_from_map(self, wx: float, wy: float):
        self._inp_x.setText(f"{wx:.2f}")
        self._inp_y.setText(f"{wy:.2f}")
        self.append_log(f"Goal từ bản đồ: ({wx:.2f}, {wy:.2f})", "info")
        self._on_plan()

    def append_log(self, msg: str, level: str = "info"):
        colors = {"info": "#185fa5", "warn": "#854f0b", "ok": "#0f6e56"}
        color  = colors.get(level, "#3d3d3a")
        ts     = time.strftime("%H:%M:%S")
        self._log.append(
            f'<span style="color:#888">{ts}</span> '
            f'<span style="color:{color}">{msg}</span>'
        )
        sb = self._log.verticalScrollBar()
        sb.setValue(sb.maximum())

    # ── Refresh ───────────────────────────────────────
    def _refresh(self):
        pose  = get_pose()
        ctrl  = get_ctrl_state()
        state = ctrl["state"].upper()

        styles = {
            "FOLLOWING": "background:#e1f5ee;color:#0f6e56",
            "STOPPED":   "background:#faece7;color:#993c1d",
            "REACHED":   "background:#eeedfe;color:#3c3489",
            "IDLE":      "background:#f1efe8;color:#5f5e5a",
        }
        s = styles.get(state, styles["IDLE"])
        self._lbl_state.setStyleSheet(
            f"font-weight:500;padding:3px;border-radius:6px;font-size:12px;{s}"
        )
        self._lbl_state.setText(state)
        self._lbl_x.setText(f"{pose['x']:.3f}")
        self._lbl_y.setText(f"{pose['y']:.3f}")
        self._lbl_t.setText(f"{math.degrees(pose['theta']):.1f}")
        self._lbl_v.setText(f"{ctrl['v']:.3f}")
        self._lbl_w.setText(f"{ctrl['w']:.3f}")
        self._lbl_bat.setText("11.2")   # TODO: đọc từ shared_state
