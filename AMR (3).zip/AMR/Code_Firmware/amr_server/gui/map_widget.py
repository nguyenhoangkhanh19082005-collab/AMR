# ══════════════════════════════════════════════════════
#  gui/map_widget.py — Widget vẽ bản đồ real-time
#  Hỗ trợ zoom (scroll) + pan (kéo) + double-click goal
# ══════════════════════════════════════════════════════
import math
from PyQt5.QtWidgets import QWidget
from PyQt5.QtCore    import Qt, QTimer, QPointF, pyqtSignal
from PyQt5.QtGui     import (QPainter, QColor, QPen, QBrush,
                              QFont, QPolygonF)
from shared_state    import get_grid_copy, get_pose, get_path, grid_to_prob
from config          import GRID_SIZE, RESOLUTION, GRID_ORIGIN  # type: ignore

GRID_ORIGIN_VAL = GRID_SIZE // 2

COLOR_ROBOT    = QColor(29,  158, 117)
COLOR_PATH     = QColor(83,  74,  183)
COLOR_GOAL     = QColor(83,  74,  183)
COLOR_BG       = QColor(248, 247, 242)


class MapWidget(QWidget):
    goal_selected = pyqtSignal(float, float)   # double-click → đặt goal

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(480, 480)
        self._scale    = 4.0
        self._offset_x = 0.0
        self._offset_y = 0.0
        self._drag_start = None

        p = self.palette()
        p.setColor(self.backgroundRole(), COLOR_BG)
        self.setPalette(p)
        self.setAutoFillBackground(True)

        self._timer = QTimer(self)
        self._timer.timeout.connect(self.update)
        self._timer.start(100)   # 10 Hz

    # ── Zoom / Pan ────────────────────────────────────
    def wheelEvent(self, event):
        f = 1.15 if event.angleDelta().y() > 0 else 1.0 / 1.15
        self._scale = max(1.0, min(30.0, self._scale * f))
        self.update()

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._drag_start = event.pos()

    def mouseMoveEvent(self, event):
        if self._drag_start:
            self._offset_x += event.pos().x() - self._drag_start.x()
            self._offset_y += event.pos().y() - self._drag_start.y()
            self._drag_start = event.pos()
            self.update()

    def mouseReleaseEvent(self, event):
        self._drag_start = None

    def mouseDoubleClickEvent(self, event):
        wx, wy = self._screen_to_world(event.pos().x(), event.pos().y())
        self.goal_selected.emit(wx, wy)

    # ── Coordinates ───────────────────────────────────
    def _world_to_screen(self, wx, wy):
        cx = self.width()  / 2 + self._offset_x
        cy = self.height() / 2 + self._offset_y
        return cx + wx / RESOLUTION * self._scale, cy - wy / RESOLUTION * self._scale

    def _screen_to_world(self, sx, sy):
        cx = self.width()  / 2 + self._offset_x
        cy = self.height() / 2 + self._offset_y
        return (sx - cx) / self._scale * RESOLUTION, (cy - sy) / self._scale * RESOLUTION

    # ── Paint ─────────────────────────────────────────
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        self._draw_grid_map(painter)
        self._draw_path(painter)
        self._draw_robot(painter)
        self._draw_hud(painter)
        painter.end()

    def _draw_grid_map(self, painter):
        prob = grid_to_prob(get_grid_copy())
        s    = self._scale
        cx   = self.width()  / 2 + self._offset_x
        cy   = self.height() / 2 + self._offset_y
        origin = GRID_ORIGIN_VAL

        col_min = max(0, int((0 - cx) / s) + origin)
        col_max = min(GRID_SIZE, int((self.width() - cx) / s) + origin + 1)
        row_min = max(0, int((cy - self.height()) / s) + origin)
        row_max = min(GRID_SIZE, int(cy / s) + origin + 1)

        for row in range(row_min, row_max):
            for col in range(col_min, col_max):
                p = prob[row, col]
                if 0.45 < p < 0.55:
                    continue
                if p >= 0.55:
                    intensity = int((p - 0.55) / 0.45 * 180)
                    color = QColor(60 + intensity // 4, 40, 40)
                else:
                    intensity = int((0.45 - p) / 0.45 * 80)
                    color = QColor(230 + intensity // 4, 230, 225)
                wx = (col - origin) * RESOLUTION
                wy = (row - origin) * RESOLUTION
                sx, sy = self._world_to_screen(wx, wy)
                painter.fillRect(int(sx), int(sy - s), max(1, int(s)), max(1, int(s)), color)

    def _draw_path(self, painter):
        waypoints = get_path()
        if not waypoints:
            return
        pen = QPen(COLOR_PATH, 2.0, Qt.DashLine)
        pen.setDashPattern([6, 3])
        painter.setPen(pen)
        pts = [QPointF(*self._world_to_screen(wx, wy)) for wx, wy in waypoints]
        for i in range(len(pts) - 1):
            painter.drawLine(pts[i], pts[i + 1])
        painter.setPen(Qt.NoPen)
        painter.setBrush(QBrush(COLOR_PATH))
        for pt in pts[:-1]:
            painter.drawEllipse(pt, 3, 3)
        gx, gy = self._world_to_screen(*waypoints[-1])
        painter.setPen(QPen(COLOR_GOAL, 2.0))
        painter.setBrush(Qt.NoBrush)
        painter.drawEllipse(QPointF(gx, gy), 7, 7)
        painter.drawEllipse(QPointF(gx, gy), 2, 2)

    def _draw_robot(self, painter):
        pose = get_pose()
        rx, ry, rtheta = pose["x"], pose["y"], pose["theta"]
        sx, sy = self._world_to_screen(rx, ry)
        r = max(6.0, self._scale * 1.5)

        painter.save()
        painter.translate(sx, sy)
        painter.rotate(-math.degrees(rtheta))
        tri = QPolygonF([QPointF(0, -r * 1.4), QPointF(-r, r), QPointF(r, r)])
        painter.setPen(QPen(QColor(15, 110, 86), 1.5))
        painter.setBrush(QBrush(COLOR_ROBOT))
        painter.drawPolygon(tri)
        painter.restore()

        painter.setPen(QPen(QColor(60, 60, 60)))
        painter.setFont(QFont("Courier", 9))
        painter.drawText(
            int(sx + r + 4), int(sy + 4),
            f"({rx:.2f}, {ry:.2f})  {math.degrees(rtheta):.0f}°"
        )

    def _draw_hud(self, painter):
        painter.setPen(QPen(QColor(130, 128, 120)))
        painter.setFont(QFont("Courier", 9))
        bar_px = int(1.0 / RESOLUTION * self._scale)
        bx, by = 16, self.height() - 24
        painter.drawLine(bx, by, bx + bar_px, by)
        painter.drawLine(bx, by - 4, bx, by + 4)
        painter.drawLine(bx + bar_px, by - 4, bx + bar_px, by + 4)
        painter.drawText(bx + bar_px // 2 - 8, by - 6, "1 m")
        painter.drawText(self.width() - 60, self.height() - 10, f"×{self._scale:.1f}")
