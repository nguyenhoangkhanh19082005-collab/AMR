# ══════════════════════════════════════════════════════
#  gui/camera_widget.py — Hiển thị MJPEG stream từ RPi
# ══════════════════════════════════════════════════════
import threading
import urllib.request
import numpy as np
try:
    import cv2
    HAS_CV2 = True
except ImportError:
    HAS_CV2 = False

from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QHBoxLayout
from PyQt5.QtCore    import Qt, QTimer
from PyQt5.QtGui     import QImage, QPixmap, QFont
from config          import STREAM_URL


class CameraWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)

        # Header
        hdr = QHBoxLayout()
        lbl_title = QLabel("Camera (RPi)")
        lbl_title.setStyleSheet("font-size:11px;font-weight:500;color:#888780;text-transform:uppercase")
        self._lbl_fps = QLabel("— fps")
        self._lbl_fps.setStyleSheet("font-size:10px;color:#3b6d11")
        hdr.addWidget(lbl_title)
        hdr.addStretch()
        hdr.addWidget(self._lbl_fps)
        layout.addLayout(hdr)

        # Video area
        self._video = QLabel("Đang kết nối camera...")
        self._video.setAlignment(Qt.AlignCenter)
        self._video.setStyleSheet(
            "background:#111;color:#555;border-radius:6px;font-size:12px"
        )
        self._video.setMinimumHeight(150)
        layout.addWidget(self._video)

        self._frame = None
        self._lock  = threading.Lock()
        self._fps   = 0

        if HAS_CV2:
            threading.Thread(target=self._read_stream, daemon=True).start()
        else:
            self._video.setText("Cần cài opencv-python\npip install opencv-python")

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._update_ui)
        self._timer.start(33)   # ~30 Hz

    def _read_stream(self):
        import time
        while True:
            try:
                stream  = urllib.request.urlopen(STREAM_URL, timeout=5)
                buf     = b""
                t_last  = time.time()
                count   = 0
                while True:
                    buf += stream.read(4096)
                    a = buf.find(b'\xff\xd8')
                    b = buf.find(b'\xff\xd9')
                    if a != -1 and b != -1:
                        jpg   = buf[a:b + 2]
                        buf   = buf[b + 2:]
                        frame = cv2.imdecode(
                            np.frombuffer(jpg, np.uint8), cv2.IMREAD_COLOR
                        )
                        if frame is not None:
                            with self._lock:
                                self._frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                            count += 1
                            now = time.time()
                            if now - t_last >= 1.0:
                                self._fps = count
                                count     = 0
                                t_last    = now
            except Exception:
                import time as t; t.sleep(2.0)

    def _update_ui(self):
        with self._lock:
            frame = self._frame
        if frame is None:
            return
        h, w, ch = frame.shape
        qimg = QImage(frame.data, w, h, ch * w, QImage.Format_RGB888)
        pix  = QPixmap.fromImage(qimg).scaled(
            self._video.width(), self._video.height(),
            Qt.KeepAspectRatio, Qt.SmoothTransformation
        )
        self._video.setPixmap(pix)
        self._lbl_fps.setText(f"{self._fps} fps")
