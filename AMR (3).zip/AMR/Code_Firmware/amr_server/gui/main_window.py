# ══════════════════════════════════════════════════════
#  gui/main_window.py — Cửa sổ chính PyQt5
# ══════════════════════════════════════════════════════
from PyQt5.QtWidgets import (QMainWindow, QWidget,
                              QHBoxLayout, QVBoxLayout)
from PyQt5.QtGui     import QKeySequence
from PyQt5.QtWidgets import QShortcut
from gui.map_widget    import MapWidget
from gui.control_panel import ControlPanel
from gui.camera_widget import CameraWidget
from controller         import emergency_stop


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("AMR Server — Bảng điều khiển")
        self.resize(920, 660)
        self._build_ui()
        self._setup_shortcuts()

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        main = QHBoxLayout(central)
        main.setContentsMargins(8, 8, 8, 8)
        main.setSpacing(8)

        # Cột trái: bản đồ (trên) + camera (dưới)
        left = QVBoxLayout()
        left.setSpacing(8)
        self._map = MapWidget()
        self._cam = CameraWidget()
        self._cam.setMaximumHeight(210)
        left.addWidget(self._map, stretch=3)
        left.addWidget(self._cam, stretch=1)

        # Cột phải: control panel
        self._ctrl = ControlPanel()

        # Double-click bản đồ → đặt goal
        self._map.goal_selected.connect(self._ctrl.set_goal_from_map)

        main.addLayout(left, stretch=1)
        main.addWidget(self._ctrl)

    def _setup_shortcuts(self):
        # Space = emergency stop
        QShortcut(QKeySequence("Space"), self).activated.connect(
            lambda: (emergency_stop(),
                     self._ctrl.append_log("STOP (Space)", "warn"))
        )

    def closeEvent(self, event):
        emergency_stop()
        super().closeEvent(event)
