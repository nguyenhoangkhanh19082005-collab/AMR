# ══════════════════════════════════════════════════════
#  controller.py — Module ⑤: Pure Pursuit Controller
#  Waypoints → (v, w) → ESP32 | 20 Hz | máy trạng thái
# ══════════════════════════════════════════════════════
import math
import time
import logging
from shared_state import get_pose, get_path, set_ctrl_state, get_latest_laser
from cmd_sender   import send_cmd, send_stop
from config       import LASER_ANGLES

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [CTRL] %(message)s",
    datefmt="%H:%M:%S"
)

# ── Tham số điều khiển ────────────────────────────────
LOOKAHEAD_DIST = 0.30    # m
V_MAX          = 0.20    # m/s
V_MIN          = 0.05    # m/s
W_MAX          = 1.50    # rad/s
GOAL_TOLERANCE = 0.08    # m
WP_TOLERANCE   = 0.10    # m
CONTROL_HZ     = 20
OBSTACLE_DIST  = 0.15    # m — phát hiện vật cản phía trước

# ── Vùng kiểm tra vật cản phía trước ───────────────────
# Với 8 cảm biến cố định mỗi 45° (0,45,90,...,315),
# "phía trước" = tia 0° và 2 tia liền kề ±45° (315°, 45°)
FRONT_CHECK_ANGLES = {0, 45, 315}


def _obstacle_ahead() -> bool:
    """
    Kiểm tra vật cản ở các tia laser phía trước robot
    (0°, ±45°) trong tầm OBSTACLE_DIST.
    """
    laser = get_latest_laser()
    dist_list = laser["dist"]   # [d0, d45, d90, ..., d315] mm

    for angle_deg, dist_mm in zip(LASER_ANGLES, dist_list):
        if angle_deg not in FRONT_CHECK_ANGLES:
            continue
        if dist_mm == -1:
            continue
        if (dist_mm / 1000.0) < OBSTACLE_DIST:
            return True
    return False


# ── Pure Pursuit ──────────────────────────────────────
def _find_lookahead(waypoints, rx, ry, current_idx):
    for i in range(current_idx, len(waypoints)):
        wx, wy = waypoints[i]
        if math.hypot(wx - rx, wy - ry) >= LOOKAHEAD_DIST:
            return wx, wy, i
    if waypoints:
        wx, wy = waypoints[-1]
        return wx, wy, len(waypoints) - 1
    return None


def _pure_pursuit(rx, ry, rtheta, lx, ly):
    dx    = lx - rx
    dy    = ly - ry
    dist  = math.hypot(dx, dy)
    alpha = math.atan2(dy, dx) - rtheta
    alpha = math.atan2(math.sin(alpha), math.cos(alpha))

    v = V_MAX * max(0.0, 1.0 - abs(alpha) / math.pi)
    v = max(V_MIN, min(V_MAX, v))

    w = (2.0 * v * math.sin(alpha) / LOOKAHEAD_DIST) if dist > 1e-6 else 0.0
    w = max(-W_MAX, min(W_MAX, w))
    return v, w


# ── Vòng lặp điều khiển ───────────────────────────────
def run_controller():
    dt     = 1.0 / CONTROL_HZ
    wp_idx = 0
    state  = "idle"
    logging.info("Controller thread khởi động.")

    while True:
        t0 = time.time()

        waypoints       = get_path()
        pose            = get_pose()
        rx, ry, rtheta  = pose["x"], pose["y"], pose["theta"]

        if not waypoints:
            if state != "idle":
                state = "idle"
                send_stop()
                logging.info("Không có path — dừng.")

        elif state == "idle":
            state  = "following"
            wp_idx = 0
            logging.info(f"Bắt đầu bám path: {len(waypoints)} waypoints")

        elif state == "following":
            if _obstacle_ahead():
                state = "stopped"
                send_stop()
                logging.warning("Phát hiện vật cản! Dừng — chờ re-plan.")
                set_ctrl_state(state="stopped", v=0.0, w=0.0)
                time.sleep(dt); continue

            gx, gy = waypoints[-1]
            if math.hypot(gx - rx, gy - ry) < GOAL_TOLERANCE:
                state = "reached"
                send_stop()
                logging.info(f"Đã đến đích! ({gx:.2f}, {gy:.2f})")
                set_ctrl_state(state="reached", v=0.0, w=0.0)
                time.sleep(dt); continue

            while wp_idx < len(waypoints) - 1:
                wx, wy = waypoints[wp_idx]
                if math.hypot(wx - rx, wy - ry) < WP_TOLERANCE:
                    wp_idx += 1
                else:
                    break

            result = _find_lookahead(waypoints, rx, ry, wp_idx)
            if result is None:
                send_stop(); time.sleep(dt); continue

            lx, ly, wp_idx = result
            v, w = _pure_pursuit(rx, ry, rtheta, lx, ly)
            send_cmd(v, w)
            set_ctrl_state(state="following", v=v, w=w, wp_idx=wp_idx)

        elif state == "stopped":
            new_path = get_path()
            if new_path and new_path != waypoints:
                state  = "following"
                wp_idx = 0
                logging.info("Nhận path mới — tiếp tục.")

        elif state == "reached":
            time.sleep(1.0)
            state  = "idle"
            wp_idx = 0
            set_ctrl_state(state="idle")

        elapsed = time.time() - t0
        time.sleep(max(0.0, dt - elapsed))


def emergency_stop():
    send_stop()
    set_ctrl_state(state="idle", v=0.0, w=0.0)
    logging.warning("EMERGENCY STOP!")
