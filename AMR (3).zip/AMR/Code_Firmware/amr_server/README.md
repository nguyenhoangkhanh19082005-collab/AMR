# AMR Server — Vai trò 3: Thuật toán & Giao diện

Hệ thống server Python chạy trên laptop Windows, nhận dữ liệu từ RPi Zero 2W
(RPi đọc UART từ ESP32: encoder + IMU + 8 cảm biến laser VL53L0X/VL53L1X),
thực hiện SLAM, lập kế hoạch đường đi và điều khiển robot AMR.

---

## Kiến trúc dữ liệu (MỚI — 1 luồng duy nhất)

```
ESP32 ──UART──▶ RPi Zero 2W ──TCP:5000──▶ socket_server.py
  │                                            │
  ├─ Encoder (l, r)                          data_queue
  ├─ IMU (gz, ax, ay)                          │
  └─ 8x laser VL53L0X (0,45,...,315 do)       EKF ──▶ pose(x,y,theta)
                                                │
                                          laser_queue
                                                │
                                          Map Builder ──▶ occupancy_grid
                                                │
                                    pose + grid ──▶ Path Planner (A*)
                                                │
                                    waypoints ──▶ Controller (Pure Pursuit)
                                                │
                              v, w ──TCP:5000 (cung socket)──▶ RPi ──UART──▶ ESP32
```

Chỉ **1 port (5000)**, **1 socket** giữa RPi và server — cả 2 chiều
(RPi → server: sensor data | server → RPi: lệnh v,w).

---

## Cấu trúc

```
amr_server/
├── config.py            # IP, port, thông số robot, 8 góc laser
├── shared_state.py       # Data bus chung (queue, pose, grid, path, rpi_conn)
├── socket_server.py      # Nhận packet gộp từ RPi (port 5000), lưu conn
├── ekf_odometry.py        # EKF + Odometry SLAM, forward laser cho Map
├── map_builder.py         # Occupancy Grid từ 8 tia laser cố định
├── path_planner.py        # A* Path Planning + obstacle inflation
├── cmd_sender.py           # Gửi v,w ngược lại RPi qua socket đang mở
├── controller.py           # Pure Pursuit (20Hz) + obstacle check 8 hướng
├── data_simulator.py       # Giả lập RPi gửi packet gộp để test
├── gui_launcher.py          # Entry point: backend + GUI
├── requirements.txt
└── gui/
    ├── main_window.py
    ├── map_widget.py
    ├── control_panel.py
    └── camera_widget.py
```

---

## Cài đặt

```bash
pip install -r requirements.txt
```

---

## Chạy

```bash
# Terminal 1 — backend + GUI
python gui_launcher.py

# Terminal 2 — giả lập RPi (robot đứng yên, test Map/Path)
python data_simulator.py
```

---

## Cấu hình quan trọng (config.py)

| Tham số | Mặc định | Mô tả |
|---|---|---|
| RPI_IP | 192.168.1.51 | IP của RPi Zero 2W |
| SERVER_PORT | 5000 | Port duy nhất — cả sensor data và lệnh điều khiển |
| NUM_LASERS | 8 | Số cảm biến laser cố định |
| LASER_ANGLES | [0,45,90,...,315] | Góc lắp mỗi cảm biến (độ, CCW từ phía trước) |
| LASER_MIN_MM / LASER_MAX_MM | 30 / 4000 | Tầm đo VL53L0X/VL53L1X |
| WHEEL_RADIUS | 0.033 m | Bán kính bánh xe |
| WHEELBASE | 0.160 m | Khoảng cách 2 bánh |
| TICKS_PER_REV | 1000 | Encoder ticks/vòng |
| ROBOT_RADIUS_M | 0.12 m | Bán kính robot (inflate obstacles) |
| GRID_SIZE / RESOLUTION | 400 / 0.05 | Bản đồ 20m x 20m, 5cm/ô |

---

## Phím tắt GUI

| Phím | Chức năng |
|---|---|
| Space | Emergency Stop |
| Scroll wheel | Zoom bản đồ |
| Kéo chuột | Pan bản đồ |
| Double-click bản đồ | Đặt goal tại vị trí đó |

---

## Format JSON: RPi -> Server (port 5000)

```json
{
  "ts":    1717724703.123,
  "enc":   {"l": 12450, "r": 12448},
  "imu":   {"gz": 0.0312, "ax": 0.012, "ay": -0.003},
  "laser": [320, -1, 1850, 410, 295, 2100, -1, 380],
  "bat":   11.2
}
```
- laser: 8 giá trị mm, theo đúng thứ tự LASER_ANGLES = [0,45,90,135,180,225,270,315]
- -1 = ngoài tầm đo / lỗi cảm biến
- Kết thúc bằng \n

## Format JSON: Server -> RPi (lệnh điều khiển, cùng socket)

```json
{"v": 0.15, "w": 0.02}
```
- v: m/s, w: rad/s (+ = quay trái)
- RPi forward xuống ESP32 qua UART
- Kết thúc bằng \n

---

## Firmware cần cập nhật (Vai trò 1 & 2)

- ESP32: đọc 8x VL53L0X qua I2C multiplexer (TCA9548A — vì VL53L0X cùng
  địa chỉ I2C mặc định 0x29), gói cùng encoder+IMU, gửi UART lên RPi.
- RPi: đọc UART từ ESP32, parse, forward thành 1 JSON packet lên server
  qua TCP. Đồng thời lắng nghe lệnh {"v","w"} từ server, forward UART
  xuống ESP32.
