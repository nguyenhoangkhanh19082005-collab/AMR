# ══════════════════════════════════════════════════════
#  map_builder.py — Module ③: Occupancy Grid Map Builder
#  Đọc 8 tia laser cố định (mỗi 45°) + EKF pose
#  → cập nhật bản đồ log-odds
# ══════════════════════════════════════════════════════
import numpy as np
import math
import logging
import time
from shared_state import (
    laser_queue, get_pose,
    grid_lock, occupancy_grid,
    grid_to_prob,
    GRID_SIZE, GRID_ORIGIN
)
from config import RESOLUTION, LASER_ANGLES, LASER_MIN_MM, LASER_MAX_MM

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [MAP] %(message)s",
    datefmt="%H:%M:%S"
)

# ── Tham số log-odds ──────────────────────────────────
L_OCC  =  0.85     # mỗi lần thấy vật cản
L_FREE = -0.40     # mỗi ô thoáng dọc tia
L_MIN  = -5.0
L_MAX  =  5.0

# ── Lọc điểm laser ────────────────────────────────────
MIN_DIST_M = LASER_MIN_MM / 1000.0
MAX_DIST_M = LASER_MAX_MM / 1000.0


def world_to_grid(wx: float, wy: float) -> tuple[int, int]:
    col = int(wx / RESOLUTION) + GRID_ORIGIN
    row = int(wy / RESOLUTION) + GRID_ORIGIN
    return row, col

def grid_to_world(row: int, col: int) -> tuple[float, float]:
    wx = (col - GRID_ORIGIN) * RESOLUTION
    wy = (row - GRID_ORIGIN) * RESOLUTION
    return wx, wy

def in_bounds(row: int, col: int) -> bool:
    return 0 <= row < GRID_SIZE and 0 <= col < GRID_SIZE


def bresenham(r0, c0, r1, c1) -> list[tuple[int, int]]:
    """Ray casting: danh sách ô từ (r0,c0) đến (r1,c1)."""
    cells = []
    dr = abs(r1 - r0); dc = abs(c1 - c0)
    sr = 1 if r1 > r0 else -1
    sc = 1 if c1 > c0 else -1
    err = dr - dc
    r, c = r0, c0
    while True:
        cells.append((r, c))
        if r == r1 and c == c1:
            break
        e2 = 2 * err
        if e2 > -dc: err -= dc; r += sr
        if e2 <  dr: err += dr; c += sc
    return cells


def process_laser(laser_mm: list, rx: float, ry: float, rtheta: float):
    """
    Chiếu 8 tia laser cố định (mỗi 45°) lên occupancy grid.
    laser_mm: list 8 giá trị (mm), -1 = out of range.
    Góc laser_mm[i] tương ứng LASER_ANGLES[i] (độ, gắn cứng trên robot).
    """
    r_row, r_col = world_to_grid(rx, ry)

    free_cells = []
    occ_cells  = []

    for angle_deg, dist_mm in zip(LASER_ANGLES, laser_mm):
        if dist_mm == -1:
            continue
        dist_m = dist_mm / 1000.0
        if dist_m < MIN_DIST_M or dist_m > MAX_DIST_M:
            continue

        # Góc tuyệt đối = hướng robot + góc lắp cảm biến
        angle_world = rtheta + math.radians(angle_deg)
        wx = rx + dist_m * math.cos(angle_world)
        wy = ry + dist_m * math.sin(angle_world)

        p_row, p_col = world_to_grid(wx, wy)
        if not in_bounds(p_row, p_col):
            continue

        ray = bresenham(r_row, r_col, p_row, p_col)
        for row, col in ray[:-1]:
            if in_bounds(row, col):
                free_cells.append((row, col))
        occ_cells.append((p_row, p_col))

    if free_cells or occ_cells:
        with grid_lock:
            for row, col in free_cells:
                occupancy_grid[row, col] = max(
                    L_MIN, occupancy_grid[row, col] + L_FREE
                )
            for row, col in occ_cells:
                occupancy_grid[row, col] = min(
                    L_MAX, occupancy_grid[row, col] + L_OCC
                )


def save_grid_png(filepath: str = "map.png"):
    """Lưu bản đồ ra PNG (cần opencv-python)."""
    try:
        import cv2
        from shared_state import get_grid_copy
        prob = grid_to_prob(get_grid_copy())
        img  = ((1.0 - prob) * 255).astype(np.uint8)
        cv2.imwrite(filepath, img)
        logging.info(f"Đã lưu bản đồ: {filepath}")
    except ImportError:
        logging.warning("Cần cài: pip install opencv-python")


def run_map_builder():
    """
    Đọc packet từ laser_queue (đã forward bởi EKF, có pose mới nhất).
    Mỗi packet có field 'laser' (8 giá trị mm, mỗi 45°)
    → chiếu lên occupancy grid tại pose hiện tại.
    """
    scan_count = 0
    t_start    = time.time()
    logging.info("Map Builder thread khởi động.")

    while True:
        data = laser_queue.get()
        try:
            laser = data.get("laser")
            if laser is None:
                continue

            p = get_pose()
            process_laser(laser, p["x"], p["y"], p["theta"])

            scan_count += 1
            if scan_count % 100 == 0:
                hz = scan_count / (time.time() - t_start)
                logging.info(
                    f"Đã xử lý {scan_count} laser-frame | "
                    f"{hz:.1f} Hz | queue={laser_queue.qsize()}"
                )
        except Exception as e:
            logging.error(f"Lỗi xử lý laser: {e}", exc_info=True)
