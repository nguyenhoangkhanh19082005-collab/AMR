# ══════════════════════════════════════════════════════
#  shared_state.py — Data bus chung giữa tất cả module
# ══════════════════════════════════════════════════════
import threading
import queue
import numpy as np
from config import GRID_SIZE, RESOLUTION

GRID_ORIGIN = GRID_SIZE // 2   # robot xuất phát ở tâm grid

# ── ① RPi gửi packet gộp (enc+imu+laser) → EKF ───────
data_queue = queue.Queue(maxsize=100)

# ── EKF forward packet (đã có pose mới) → Map Builder ─
laser_queue = queue.Queue(maxsize=100)

# ── Laser scan mới nhất (8 hướng cố định, mm) ────────
laser_lock  = threading.Lock()
latest_laser = {"ts": 0.0, "dist": [-1] * 8}   # mm, -1 = out of range

def get_latest_laser():
    with laser_lock:
        return dict(latest_laser)

def set_latest_laser(ts, dist_list):
    with laser_lock:
        latest_laser["ts"]   = ts
        latest_laser["dist"] = list(dist_list)

# ── ② EKF pose (ghi bởi EKF, đọc bởi tất cả) ─────────
pose_lock = threading.Lock()
pose = {"x": 0.0, "y": 0.0, "theta": 0.0, "ts": 0.0}

def get_pose():
    with pose_lock:
        return pose.copy()

def set_pose(x, y, theta, ts):
    with pose_lock:
        pose["x"] = x
        pose["y"] = y
        pose["theta"] = theta
        pose["ts"] = ts

# ── ③ Occupancy grid ──────────────────────────────────
grid_lock = threading.Lock()
occupancy_grid = np.zeros((GRID_SIZE, GRID_SIZE), dtype=np.float32)
# float32 log-odds: 0=unknown, >0=obstacle, <0=free

def get_grid_copy():
    with grid_lock:
        return occupancy_grid.copy()

def grid_to_prob(grid: np.ndarray) -> np.ndarray:
    """Log-odds → xác suất [0,1]. >0.6=obstacle, <0.4=free."""
    return 1.0 - 1.0 / (1.0 + np.exp(grid))

# ── ④ Path ────────────────────────────────────────────
path_lock    = threading.Lock()
current_path = []
path_status  = {"state": "idle"}   # idle|planning|ready|failed

def get_path():
    with path_lock:
        return list(current_path)

def set_path(waypoints: list, state: str = "ready"):
    with path_lock:
        current_path.clear()
        current_path.extend(waypoints)
        path_status["state"] = state

# ── ⑤ Controller state ────────────────────────────────
ctrl_lock  = threading.Lock()
ctrl_state = {
    "state":  "idle",    # idle|following|reached|stopped
    "v":       0.0,
    "w":       0.0,
    "wp_idx":  0,
    "goal":   (0.0, 0.0),
}

def get_ctrl_state():
    with ctrl_lock:
        return dict(ctrl_state)

def set_ctrl_state(**kwargs):
    with ctrl_lock:
        ctrl_state.update(kwargs)

# ── Kết nối clients ───────────────────────────────────
connection_lock   = threading.Lock()
connected_clients = {}

# ── RPi connection (dùng để gửi lệnh ngược lại) ───────
rpi_conn_lock = threading.Lock()
_rpi_conn     = None

def set_rpi_conn(conn):
    global _rpi_conn
    with rpi_conn_lock:
        _rpi_conn = conn

def get_rpi_conn():
    with rpi_conn_lock:
        return _rpi_conn
