# ══════════════════════════════════════════════════════
#  path_planner.py — Module ④: A* Path Planner
#  Inflate obstacles → A* → smooth → waypoints (m)
# ══════════════════════════════════════════════════════
import numpy as np
import heapq
import math
import logging
import time
from scipy.ndimage import binary_dilation
from config import RESOLUTION, ROBOT_RADIUS_M
from shared_state import (
    get_grid_copy, get_pose, set_path,
    grid_to_prob, GRID_SIZE, GRID_ORIGIN
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [PATH] %(message)s",
    datefmt="%H:%M:%S"
)

OBSTACLE_THRESH = 0.6
INFLATE_CELLS   = int(math.ceil(ROBOT_RADIUS_M / RESOLUTION))
MOVE_STRAIGHT   = 1.0
MOVE_DIAGONAL   = math.sqrt(2)


# ── Coordinate helpers ────────────────────────────────
def world_to_grid(wx, wy):
    return int(wy / RESOLUTION) + GRID_ORIGIN, int(wx / RESOLUTION) + GRID_ORIGIN

def grid_to_world(row, col):
    return (col - GRID_ORIGIN) * RESOLUTION, (row - GRID_ORIGIN) * RESOLUTION

def in_bounds(row, col):
    return 0 <= row < GRID_SIZE and 0 <= col < GRID_SIZE


# ── Bước 1: Inflate obstacles ─────────────────────────
def inflate_grid(prob_grid: np.ndarray) -> np.ndarray:
    mask = prob_grid > OBSTACLE_THRESH
    if INFLATE_CELLS > 0:
        struct   = np.ones((2 * INFLATE_CELLS + 1,) * 2, dtype=bool)
        inflated = binary_dilation(mask, structure=struct)
    else:
        inflated = mask
    return inflated


# ── Bước 2: A* ────────────────────────────────────────
def astar(blocked, start, goal):
    sr, sc = start
    gr, gc = goal

    if blocked[sr, sc] or blocked[gr, gc]:
        logging.warning("Start hoặc Goal nằm trong vật cản!")
        return None

    open_heap = [(0.0, 0.0, sr, sc)]
    came_from = {}
    g_score   = np.full((GRID_SIZE, GRID_SIZE), np.inf, dtype=np.float32)
    g_score[sr, sc] = 0.0

    dirs = [
        (-1,  0, MOVE_STRAIGHT), ( 1,  0, MOVE_STRAIGHT),
        ( 0, -1, MOVE_STRAIGHT), ( 0,  1, MOVE_STRAIGHT),
        (-1, -1, MOVE_DIAGONAL), (-1,  1, MOVE_DIAGONAL),
        ( 1, -1, MOVE_DIAGONAL), ( 1,  1, MOVE_DIAGONAL),
    ]

    while open_heap:
        f, g, r, c = heapq.heappop(open_heap)
        if r == gr and c == gc:
            return _reconstruct(came_from, (gr, gc))
        if g > g_score[r, c] + 1e-6:
            continue
        for dr, dc, cost in dirs:
            nr, nc = r + dr, c + dc
            if not in_bounds(nr, nc) or blocked[nr, nc]:
                continue
            tg = g_score[r, c] + cost
            if tg < g_score[nr, nc]:
                g_score[nr, nc] = tg
                heapq.heappush(open_heap,
                               (tg + math.hypot(gr - nr, gc - nc), tg, nr, nc))
                came_from[(nr, nc)] = (r, c)
    return None


def _reconstruct(came_from, current):
    path = [current]
    while current in came_from:
        current = came_from[current]
        path.append(current)
    path.reverse()
    return path


# ── Bước 3: Smooth path ───────────────────────────────
def smooth_path(path, blocked):
    if len(path) <= 2:
        return path
    smoothed = [path[0]]
    i = 0
    while i < len(path) - 1:
        j = len(path) - 1
        while j > i + 1:
            if _line_of_sight(path[i], path[j], blocked):
                break
            j -= 1
        smoothed.append(path[j])
        i = j
    return smoothed


def _line_of_sight(p1, p2, blocked):
    r0, c0 = p1; r1, c1 = p2
    dr = abs(r1 - r0); dc = abs(c1 - c0)
    sr = 1 if r1 > r0 else -1
    sc = 1 if c1 > c0 else -1
    err = dr - dc
    r, c = r0, c0
    while True:
        if not in_bounds(r, c) or blocked[r, c]:
            return False
        if r == r1 and c == c1:
            return True
        e2 = 2 * err
        if e2 > -dc: err -= dc; r += sr
        if e2 <  dr: err += dr; c += sc


# ── API chính ─────────────────────────────────────────
def plan(goal_x: float, goal_y: float) -> list | None:
    """
    Lập kế hoạch từ vị trí robot hiện tại đến (goal_x, goal_y).
    Trả về list[(x, y)] waypoints (m) hoặc None.
    """
    t0 = time.time()
    p  = get_pose()
    rx, ry = p["x"], p["y"]

    prob    = grid_to_prob(get_grid_copy())
    blocked = inflate_grid(prob)
    start   = world_to_grid(rx, ry)
    goal    = world_to_grid(goal_x, goal_y)

    logging.info(
        f"Planning: ({rx:.2f},{ry:.2f}) → ({goal_x:.2f},{goal_y:.2f})"
    )

    raw = astar(blocked, start, goal)
    if raw is None:
        logging.warning("A*: không tìm được đường!")
        set_path([], state="failed")
        return None

    smooth   = smooth_path(raw, blocked)
    waypoints = [grid_to_world(r, c) for r, c in smooth]

    logging.info(
        f"Path: {len(raw)} ô → {len(waypoints)} waypoints "
        f"| {(time.time()-t0)*1000:.1f}ms"
    )
    set_path(waypoints)
    return waypoints


def run_replanner(goal_x: float, goal_y: float, interval_s: float = 2.0):
    """Re-plan tự động mỗi interval_s giây (chạy trong thread)."""
    import time
    logging.info(
        f"Re-planner → goal=({goal_x:.2f},{goal_y:.2f}), "
        f"interval={interval_s}s"
    )
    while True:
        plan(goal_x, goal_y)
        time.sleep(interval_s)
