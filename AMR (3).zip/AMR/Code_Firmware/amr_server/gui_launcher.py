# ══════════════════════════════════════════════════════
#  gui_launcher.py — Entry point: backend + GUI
#  Chạy: python gui_launcher.py
# ══════════════════════════════════════════════════════
import sys
import threading
from PyQt5.QtWidgets import QApplication

from socket_server  import start_server
from ekf_odometry   import run_ekf
from map_builder    import run_map_builder
from controller     import run_controller, emergency_stop
from gui.main_window import MainWindow


def start_backend():
    threading.Thread(target=run_ekf,            daemon=True).start()
    threading.Thread(target=run_map_builder,    daemon=True).start()
    threading.Thread(target=run_controller,     daemon=True).start()
    threading.Thread(target=start_server,       daemon=True).start()
    print("[MAIN] Tất cả backend thread đã khởi động.")


if __name__ == "__main__":
    start_backend()

    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    app.setStyleSheet("""
        QGroupBox {
            font-size: 11px;
            font-weight: 500;
            border: 0.5px solid #d3d1c7;
            border-radius: 8px;
            margin-top: 8px;
            padding-top: 4px;
        }
        QGroupBox::title {
            subcontrol-origin: margin;
            left: 8px;
            color: #888780;
        }
        QPushButton {
            border: 0.5px solid #d3d1c7;
            border-radius: 6px;
            padding: 5px 10px;
            background: #f1efe8;
            font-size: 12px;
        }
        QPushButton:hover  { background: #e3e1da; }
        QPushButton:pressed{ background: #d3d1c7; }
        QLineEdit {
            border: 0.5px solid #d3d1c7;
            border-radius: 6px;
            padding: 4px 8px;
            font-size: 12px;
        }
        QTextEdit {
            border: 0.5px solid #d3d1c7;
            border-radius: 6px;
            font-size: 11px;
        }
    """)

    win = MainWindow()
    win.show()
    sys.exit(app.exec_())
