# ══════════════════════════════════════════════════════
#  cmd_sender.py — Gửi lệnh (v, w) xuống RPi
#  RPi forward lệnh này qua UART xuống ESP32.
#  Dùng LẠI socket RPi đã kết nối lên server (port 5000)
#  — không mở socket mới, không cần CMD_PORT riêng.
# ══════════════════════════════════════════════════════
import json
import logging
from shared_state import get_rpi_conn

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [CMD] %(message)s",
    datefmt="%H:%M:%S"
)


def send_cmd(v: float, w: float) -> bool:
    """
    Gửi lệnh (v, w) xuống RPi qua socket đang mở.
    RPi đọc dòng JSON này, forward UART → ESP32.
    v: vận tốc tịnh tiến (m/s)
    w: vận tốc quay (rad/s, + = trái)
    """
    conn = get_rpi_conn()
    if conn is None:
        logging.warning("Chưa có kết nối RPi — không gửi được lệnh")
        return False

    payload = (json.dumps({"v": round(v, 4), "w": round(w, 4)}) + "\n").encode()
    try:
        conn.sendall(payload)
        return True
    except OSError as e:
        logging.warning(f"Lỗi gửi lệnh tới RPi: {e}")
        return False


def send_stop():
    send_cmd(0.0, 0.0)
