# ══════════════════════════════════════════════════════
#  config.py — Cấu hình toàn hệ thống AMR Server
# ══════════════════════════════════════════════════════

# ── Mạng ──────────────────────────────────────────────
SERVER_IP   = "0.0.0.0"        # lắng nghe tất cả interface
SERVER_PORT = 5000             # RPi gửi packet gộp (enc+imu+laser)
CMD_PORT    = 5002             # server gửi lệnh xuống ESP32 (qua RPi forward)

ESP32_IP    = "192.168.1.50"   # IP của ESP32 (nếu cần kết nối trực tiếp)
RPI_IP      = "192.168.1.51"   # IP của Raspberry Pi Zero 2W

# ── Socket ────────────────────────────────────────────
BUFFER_SIZE    = 4096
CLIENT_TIMEOUT = 5.0           # giây
QUEUE_MAX      = 100

# ── Cảm biến laser cố định (VL53L0X/VL53L1X) ─────────
# 8 cảm biến gắn mỗi 45°, bắt đầu từ phía trước (0°) theo chiều CCW
NUM_LASERS    = 8
LASER_ANGLES  = [i * 45 for i in range(NUM_LASERS)]   # [0,45,90,...,315]
LASER_MIN_MM  = 30     # VL53L0X min range ~30mm
LASER_MAX_MM  = 4000   # VL53L1X max range ~4000mm

# ── Robot vật lý ──────────────────────────────────────
WHEEL_RADIUS   = 0.033         # m  (đường kính bánh / 2)
WHEELBASE      = 0.160         # m  (khoảng cách tâm 2 bánh)
TICKS_PER_REV  = 1000          # ticks/vòng (encoder)
ROBOT_RADIUS_M = 0.12          # m  (bán kính robot thực tế)

# ── Occupancy grid ────────────────────────────────────
GRID_SIZE   = 400              # 400×400 ô
RESOLUTION  = 0.05             # m/ô (mỗi ô = 5cm × 5cm)
GRID_ORIGIN = 200
# ── Camera stream ─────────────────────────────────────
STREAM_URL = f"http://{RPI_IP}:8080/stream.mjpg"
