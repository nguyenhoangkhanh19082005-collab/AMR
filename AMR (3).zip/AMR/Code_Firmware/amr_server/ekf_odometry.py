# ══════════════════════════════════════════════════════
#  ekf_odometry.py — Module ②: EKF + Odometry SLAM
#  State: [x, y, θ] | Predict: encoder | Update: gyro Z
# ══════════════════════════════════════════════════════
import numpy as np
import math
import logging
from config import WHEEL_RADIUS, WHEELBASE, TICKS_PER_REV
from shared_state import data_queue, laser_queue, set_pose

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [EKF] %(message)s",
    datefmt="%H:%M:%S"
)

TICK2M = (2 * math.pi * WHEEL_RADIUS) / TICKS_PER_REV  # m/tick

# ── Tham số EKF ───────────────────────────────────────
# Q: Process noise — tăng nếu encoder slip nhiều
Q = np.diag([1e-4, 1e-4, 1e-5])   # [x(m²), y(m²), θ(rad²)]

# R: Measurement noise — tăng nếu gyro nhiễu
R = np.array([[1e-2]])             # gyro Z (rad²)

# P0: Covariance khởi tạo
P0 = np.diag([0.1, 0.1, 0.1])


def _wrap_angle(a: float) -> float:
    return math.atan2(math.sin(a), math.cos(a))


class EKF:
    """
    Extended Kalman Filter cho differential-drive robot.
    State vector: [x, y, θ]
    Observation:  gyro Z tích phân → Δθ đo được
    """

    def __init__(self):
        self.x = np.zeros(3)
        self.P = P0.copy()
        self.prev_enc_l = None
        self.prev_enc_r = None
        self.prev_ts    = None
        self.gyro_yaw   = 0.0
    def reset(self, x=0.0, y=0.0, theta=0.0):
        self.x = np.array([x, y, theta])
        self.P = P0.copy()
        self.prev_enc_l = None
        self.prev_enc_r = None
        self.prev_ts    = None
        self.gyro_yaw   = theta
        logging.info(
            f"EKF reset → ({x:.3f}, {y:.3f}, {math.degrees(theta):.1f}°)"
        )

    # ── Bước 1: Predict (Odometry) ────────────────────
    def predict(self, enc_l: int, enc_r: int, dt: float):
        if self.prev_enc_l is None:
            self.prev_enc_l = enc_l
            self.prev_enc_r = enc_r
            return 0.0, 0.0

        dl = (enc_l - self.prev_enc_l) * TICK2M
        dr = (enc_r - self.prev_enc_r) * TICK2M
        self.prev_enc_l = enc_l
        self.prev_enc_r = enc_r

        ds     = (dl + dr) / 2.0
        dtheta = (dr - dl) / WHEELBASE
        theta_mid = self.x[2] + dtheta / 2.0

        self.x[0] += ds * math.cos(theta_mid)
        self.x[1] += ds * math.sin(theta_mid)
        self.x[2]  = _wrap_angle(self.x[2] + dtheta)

        F = np.eye(3)
        F[0, 2] = -ds * math.sin(theta_mid)
        F[1, 2] =  ds * math.cos(theta_mid)

        self.P = F @ self.P @ F.T + Q
        return ds, dtheta

    # ── Bước 2: Update (Gyro Z) ───────────────────────
    def update(self, gz: float, dt: float):
        self.gyro_yaw += gz * dt
        self.gyro_yaw = _wrap_angle(self.gyro_yaw)

        z = np.array([self.gyro_yaw])
        h = np.array([self.x[2]])
        y = z - h
        y[0] = _wrap_angle(y[0])

        H = np.array([[0.0, 0.0, 1.0]])
        S = H @ self.P @ H.T + R
        K = self.P @ H.T @ np.linalg.inv(S)

        self.x = self.x + (K @ y).flatten()
        self.x[2] = _wrap_angle(self.x[2])
        self.P = (np.eye(3) - K @ H) @ self.P

    @property
    def pose(self):
        return float(self.x[0]), float(self.x[1]), float(self.x[2])

    @property
    def uncertainty(self):
        return (
            math.sqrt(self.P[0, 0]),
            math.sqrt(self.P[1, 1]),
            math.sqrt(self.P[2, 2]),
        )


# ── Vòng lặp chính ────────────────────────────────────
def run_ekf():
    ekf   = EKF()
    count = 0
    logging.info("EKF thread khởi động.")

    while True:
        data = data_queue.get()

        ts    = data["ts"]
        enc_l = data["enc"]["l"]
        enc_r = data["enc"]["r"]
        gz    = data["imu"]["gz"]

        if ekf.prev_ts is None:
            ekf.prev_ts = ts
            continue

        dt = ts - ekf.prev_ts
        ekf.prev_ts = ts

        if dt <= 0 or dt > 1.0:
            logging.warning(f"dt bất thường: {dt:.3f}s — bỏ qua")
            continue

        ekf.predict(enc_l, enc_r, dt)
        ekf.update(gz, dt)

        x, y, theta = ekf.pose
        set_pose(x, y, theta, ts)

        # Forward packet (đã có pose mới nhất) cho Map Builder
        if "laser" in data:
            try:
                laser_queue.put_nowait(data)
            except Exception:
                pass   # bỏ qua nếu Map Builder chưa xử lý kịp

        count += 1
        if count % 50 == 0:
            sx, sy, sth = ekf.uncertainty
            logging.info(
                f"Pose: x={x:.3f}m  y={y:.3f}m  θ={math.degrees(theta):.1f}°"
                f" | σ=({sx:.4f}, {sy:.4f}, {math.degrees(sth):.2f}°)"
            )
