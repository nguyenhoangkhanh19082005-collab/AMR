# ══════════════════════════════════════════════════════
#  data_simulator.py — Giả lập RPi gửi packet & nhận lệnh
#  Robot giả lập có phản hồi vật lý với lệnh v, w
# ══════════════════════════════════════════════════════
import socket, json, time, math, random, select
from config import SERVER_PORT, LASER_ANGLES, WHEEL_RADIUS, WHEELBASE, TICKS_PER_REV

SERVER_IP = "127.0.0.1"
SEND_HZ   = 10

# Kích thước phòng giả lập (m)
ROOM_HALF_X = 5.0   # tường trái/phải cách tâm 2m
ROOM_HALF_Y = 5.0   # tường trước/sau cách tâm 1.5m

# Biến trạng thái vật lý ảo của robot
sim_x = 0.0
sim_y = 0.0
sim_theta = 0.0
sim_v = 0.0
sim_w = 0.0

enc_l = 0.0
enc_r = 0.0

# Hằng số quy đổi mét / tick
TICK2M = (2 * math.pi * WHEEL_RADIUS) / TICKS_PER_REV

def laser_distance_to_wall(angle_deg: float) -> int:
    """
    Phóng tia từ vị trí (sim_x, sim_y) của robot cắt với các bức tường.
    """
    global sim_x, sim_y, sim_theta
    # Góc chiếu tia tuyệt đối trong map = hướng robot + góc lắp cảm biến
    rad   = sim_theta + math.radians(angle_deg)
    cos_r = math.cos(rad)
    sin_r = math.sin(rad)

    dist_m = 99.0

    # Tìm giao điểm với tường dọc (x = ±ROOM_HALF_X)
    if abs(cos_r) > 1e-6:
        tx1 = (ROOM_HALF_X - sim_x) / cos_r
        tx2 = (-ROOM_HALF_X - sim_x) / cos_r
        if tx1 > 0: dist_m = min(dist_m, tx1)
        if tx2 > 0: dist_m = min(dist_m, tx2)

    # Tìm giao điểm với tường ngang (y = ±ROOM_HALF_Y)
    if abs(sin_r) > 1e-6:
        ty1 = (ROOM_HALF_Y - sim_y) / sin_r
        ty2 = (-ROOM_HALF_Y - sim_y) / sin_r
        if ty1 > 0: dist_m = min(dist_m, ty1)
        if ty2 > 0: dist_m = min(dist_m, ty2)

    dist_m = min(dist_m, 4.0)               # giới hạn tầm VL53L1X
    dist_m += random.gauss(0, 0.01)         # nhiễu ±1cm
    dist_m  = max(0.03, dist_m)
    return int(dist_m * 1000)

def simulate():
    global sim_x, sim_y, sim_theta, sim_v, sim_w, enc_l, enc_r

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((SERVER_IP, SERVER_PORT))
        print("[SIM] RPi kết nối! Đang tương tác 2 chiều với Server...")
        
        buffer = ""
        dt = 1.0 / SEND_HZ
        
        while True:
            # 1. Non-blocking đọc lệnh v, w từ socket
            r, _, _ = select.select([s], [], [], 0.0)
            if r:
                try:
                    data = s.recv(1024).decode()
                    if not data: break # Mất kết nối
                    
                    buffer += data
                    while "\n" in buffer:
                        line, buffer = buffer.split("\n", 1)
                        if line.strip():
                            cmd = json.loads(line)
                            if "v" in cmd and "w" in cmd:
                                sim_v = cmd["v"]
                                sim_w = cmd["w"]
                except Exception as e:
                    print(f"[SIM] Lỗi đọc lệnh: {e}")

            # 2. Forward Kinematics: Di chuyển robot ảo
            sim_x += sim_v * math.cos(sim_theta) * dt
            sim_y += sim_v * math.sin(sim_theta) * dt
            sim_theta += sim_w * dt

            # 3. Inverse Kinematics: Tính ra vận tốc từng bánh & số tick
            # vr = v + (w * L / 2) | vl = v - (w * L / 2)
            v_r = sim_v + (sim_w * WHEELBASE / 2.0)
            v_l = sim_v - (sim_w * WHEELBASE / 2.0)
            
            enc_r += (v_r * dt) / TICK2M
            enc_l += (v_l * dt) / TICK2M
            
            # Giả lập IMU: w thực tế cộng thêm một chút độ nhiễu 
            gz = sim_w + random.gauss(0.0, 0.002)

            # 4. Tính toán laser tương ứng với vị trí ảo hiện tại
            laser = [laser_distance_to_wall(a) for a in LASER_ANGLES]

            packet = {
                "ts":    round(time.time(), 3),
                "enc":   {"l": int(enc_l), "r": int(enc_r)},
                "imu":   {
                    "gz": round(gz, 4),
                    "ax": 0.0,
                    "ay": 0.0,
                },
                "laser": laser,
                "bat":   11.2,
            }
            
            try:
                s.sendall((json.dumps(packet) + "\n").encode())
            except OSError:
                print("[SIM] Server đóng kết nối.")
                break
                
            time.sleep(dt)

if __name__ == "__main__":
    print("[SIM] Simulator chạy — Ctrl+C để dừng")
    try:
        simulate()
    except KeyboardInterrupt:
        print("\n[SIM] Đã dừng.")