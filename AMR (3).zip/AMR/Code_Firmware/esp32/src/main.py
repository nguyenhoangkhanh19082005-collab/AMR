# ============================================================
# main.py – ESP32 Main Loop
# Luồng: Encoder+IMU+Laser → UART → Pi Zero 2W
#         Pi → UART → ESP32 → Motor PID
# Không có WiFi, không có HC-SR04
# ============================================================

import time, math, gc
import config
from encoder    import encoder_left, encoder_right
from mpu9250    import imu
from motor      import motor
from pid        import pid_left, pid_right
from uart_comm  import uart_comm
from sensor_laser import LaserArray          # ← THÊM MỚI


# ── Trạng thái điều khiển ───────────────────────────────────
_mode         = "stop"
_target_v     = 0.0     # m/s
_target_w     = 0.0     # rad/s
_pwm_l        = 0.0
_pwm_r        = 0.0

# Encoder tích lũy toàn bộ (không reset – server dùng để tính odometry)
_enc_l_total  = 0
_enc_r_total  = 0

# Timing
_CTRL_MS      = 10      # 100Hz – vòng điều khiển
_TX_MS        = 20      # 50Hz  – gửi UART

# Laser – đọc mỗi 5 tick TX = 10Hz           # ← THÊM MỚI
_LASER_EVERY  = 5                             # ← THÊM MỚI


def _v_to_wheels(v, w):
    """v(m/s), w(rad/s) → omega_L, omega_R (rad/s)"""
    R = config.WHEEL_RADIUS
    L = config.WHEEL_BASE
    return (v - w*L/2)/R, (v + w*L/2)/R


def _apply_cmd(cmd):
    global _mode, _target_v, _target_w, _pwm_l, _pwm_r
    if cmd is None:
        return
    mode = cmd.get("mode", "stop")

    if mode == "velocity":
        _target_v = float(cmd.get("v", 0.0))
        _target_w = float(cmd.get("w", 0.0))
        _mode = "velocity"

    elif mode == "pwm":
        _pwm_l = float(cmd.get("l", 0.0))
        _pwm_r = float(cmd.get("r", 0.0))
        _mode = "pwm"
        pid_left.reset(); pid_right.reset()

    elif mode == "stop":
        _target_v = _target_w = 0.0
        _mode = "stop"
        motor.stop()
        pid_left.reset(); pid_right.reset()

    elif mode == "brake":
        _mode = "stop"
        motor.brake()
        pid_left.reset(); pid_right.reset()

    elif mode == "pid_tune":
        pid_left.tune(cmd["kp"], cmd["ki"], cmd["kd"])
        pid_right.tune(cmd["kp"], cmd["ki"], cmd["kd"])


def _read_battery():
    try:
        from machine import ADC, Pin as _Pin
        adc = ADC(_Pin(config.BAT_ADC_PIN))
        adc.atten(ADC.ATTN_11DB)
        return round(adc.read() / 4095.0 * 3.6 * config.BAT_DIVIDER, 2)
    except:
        return 0.0


def main():
    global _enc_l_total, _enc_r_total
    global _pwm_l, _pwm_r

    print("=" * 40)
    print("  AMR ESP32 – UART Bridge Mode")
    print("=" * 40)

    encoder_left.reset()
    encoder_right.reset()

    # ── Khởi tạo laser array – dùng chung I2C với MPU9250 ──  # ← SỬA
    laser = LaserArray(i2c=imu.i2c)                            # ← SỬA
    _laser_data  = [9999] * 8   # [N,NE,E,SE,S,SW,W,NW] mm    # ← THÊM MỚI
    _laser_tick  = 0            # đếm để đọc laser mỗi 5 tick  # ← THÊM MỚI

    _last_ctrl = time.ticks_ms()
    _last_tx   = time.ticks_ms()
    _seq       = 0
    _bat_cache = 11.1
    _bat_timer = 0

    while True:
        now = time.ticks_ms()

        # ── VÒNG ĐIỀU KHIỂN 100Hz ───────────────────────────
        if time.ticks_diff(now, _last_ctrl) >= _CTRL_MS:
            dt = time.ticks_diff(now, _last_ctrl) / 1000.0
            _last_ctrl = now

            # Đọc encoder delta
            dl = encoder_left.get_and_reset()
            dr = encoder_right.get_and_reset()
            _enc_l_total += dl
            _enc_r_total += dr

            # Vận tốc hiện tại
            vl = encoder_left.velocity_rads(dl, dt)
            vr = encoder_right.velocity_rads(dr, dt)

            # Điều khiển
            if _mode == "velocity":
                sp_l, sp_r = _v_to_wheels(_target_v, _target_w)
                _pwm_l = pid_left.compute(sp_l,  vl)
                _pwm_r = pid_right.compute(sp_r, vr)
                motor.set_left(_pwm_l)
                motor.set_right(_pwm_r)
            elif _mode == "pwm":
                motor.set_left(_pwm_l)
                motor.set_right(_pwm_r)
            # else stop – motor đã dừng

            # Nhận lệnh từ Pi (non-blocking)
            cmd = uart_comm.receive_cmd()
            _apply_cmd(cmd)

        # ── VÒNG GỬI UART 50Hz ──────────────────────────────
        if time.ticks_diff(now, _last_tx) >= _TX_MS:
            _last_tx = now
            _seq    += 1

            # Đọc battery mỗi 5 giây
            if _seq % 250 == 0:
                _bat_cache = _read_battery()
                gc.collect()

            # ── Đọc laser 10Hz (mỗi 5 tick TX) ─────────────  # ← THÊM MỚI
            _laser_tick += 1                                    # ← THÊM MỚI
            if _laser_tick >= _LASER_EVERY:                     # ← THÊM MỚI
                _laser_tick  = 0                                # ← THÊM MỚI
                _laser_data  = laser.read_all()                 # ← THÊM MỚI

            imu_data = imu.read()

            # Packet gọn – key ngắn để tiết kiệm UART bandwidth
            packet = {
                "t"  : time.time(),
                "seq": _seq,
                "enc": {"l": _enc_l_total, "r": _enc_r_total},
                "imu": {
                    "ax": imu_data["ax"], "ay": imu_data["ay"],
                    "az": imu_data["az"], "gx": imu_data["gx"],
                    "gy": imu_data["gy"], "gz": imu_data["gz"],
                    "mx": imu_data["mx"], "my": imu_data["my"],
                    "mz": imu_data["mz"], "tp": imu_data["tp"]
                },
                "pwm": {"l": round(_pwm_l,1), "r": round(_pwm_r,1)},
                "bat": _bat_cache,
                "lsr": _laser_data   # [N,NE,E,SE,S,SW,W,NW] mm  # ← THÊM MỚI
            }
            uart_comm.send(packet)


main()