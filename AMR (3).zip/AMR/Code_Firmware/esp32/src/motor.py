# ============================================================
# motor.py – TB6612FNG Motor Driver
# ============================================================

from machine import Pin, PWM
import config

class MotorDriver:
    def __init__(self):
        self.stby = Pin(config.STBY, Pin.OUT)
        self.stby.value(0)

        self.ain1 = Pin(config.AIN1, Pin.OUT)
        self.ain2 = Pin(config.AIN2, Pin.OUT)
        self.pwma = PWM(Pin(config.PWMA), freq=20000)

        self.bin1 = Pin(config.BIN1, Pin.OUT)
        self.bin2 = Pin(config.BIN2, Pin.OUT)
        self.pwmb = PWM(Pin(config.PWMB), freq=20000)

        self._zero()
        self.stby.value(1)
        print("[Motor] TB6612FNG OK")

    def _zero(self):
        self.ain1.value(0); self.ain2.value(0); self.pwma.duty(0)
        self.bin1.value(0); self.bin2.value(0); self.pwmb.duty(0)

    @staticmethod
    def _duty(pct):
        return int(min(abs(pct), 100) / 100.0 * 1023)

    def set_left(self, pct):
        d = self._duty(pct)
        if pct > 0:   self.ain1.value(1); self.ain2.value(0)
        elif pct < 0: self.ain1.value(0); self.ain2.value(1)
        else:         self.ain1.value(0); self.ain2.value(0)
        self.pwma.duty(d)

    def set_right(self, pct):
        d = self._duty(pct)
        if pct > 0:   self.bin1.value(1); self.bin2.value(0)
        elif pct < 0: self.bin1.value(0); self.bin2.value(1)
        else:         self.bin1.value(0); self.bin2.value(0)
        self.pwmb.duty(d)

    def set_both(self, l, r):
        self.set_left(l); self.set_right(r)

    def stop(self):
        self._zero()

    def brake(self):
        self.ain1.value(1); self.ain2.value(1); self.pwma.duty(1023)
        self.bin1.value(1); self.bin2.value(1); self.pwmb.duty(1023)


motor = MotorDriver()