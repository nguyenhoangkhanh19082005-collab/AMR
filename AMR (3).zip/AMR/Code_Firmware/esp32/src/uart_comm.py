# ============================================================
# uart_comm.py – Giao tiếp UART với Pi Zero 2W
# Gửi: telemetry JSON (50Hz)
# Nhận: lệnh điều khiển JSON từ Pi (forward từ Server)
# ============================================================

from machine import UART, Pin
import json, time
import config

# Giới hạn buffer tránh tích lũy rác khi mất gói
_RX_BUF_MAX = 512

class UARTComm:
    def __init__(self):
        self.uart = UART(1,
                         baudrate=config.UART_BAUD,
                         tx=Pin(config.UART_TX),
                         rx=Pin(config.UART_RX),
                         timeout=10,
                         rxbuf=512)
        self._rx_buf = b""
        print(f"[UART] TX={config.UART_TX} RX={config.UART_RX} "
              f"BAUD={config.UART_BAUD}")

    def send(self, data_dict):
        """Gửi dict dưới dạng JSON + newline"""
        try:
            line = json.dumps(data_dict) + "\n"
            self.uart.write(line.encode())
        except Exception as e:
            print(f"[UART] Lỗi gửi: {e}")

    def receive_cmd(self):
        """
        Đọc non-blocking – trả về dict lệnh hoặc None.
        Tự xử lý partial data và nhiều dòng.
        Flush buffer nếu quá lớn (tránh tích lũy rác).
        """
        if self.uart.any():
            self._rx_buf += self.uart.read(self.uart.any())

        # Guard: flush nếu buffer quá lớn mà không có \n
        if len(self._rx_buf) > _RX_BUF_MAX:
            # Giữ lại phần sau \n cuối nếu có, ngược lại xóa hết
            if b"\n" in self._rx_buf:
                self._rx_buf = self._rx_buf.split(b"\n")[-1]
            else:
                self._rx_buf = b""
                return None

        if b"\n" in self._rx_buf:
            line, self._rx_buf = self._rx_buf.split(b"\n", 1)
            try:
                return json.loads(line.decode().strip())
            except:
                return None
        return None


uart_comm = UARTComm()
