# ============================================================
# encoder.py – Quadrature encoder với interrupt
# ============================================================

from machine import Pin
import config

class Encoder:
    def __init__(self, pin_a_num, pin_b_num, name=""):
        self.name    = name
        self._count  = 0
        self._pin_a  = Pin(pin_a_num, Pin.IN, Pin.PULL_UP)
        self._pin_b  = Pin(pin_b_num, Pin.IN, Pin.PULL_UP)
        self._pin_a.irq(
            trigger=Pin.IRQ_RISING | Pin.IRQ_FALLING,
            handler=self._isr
        )

    def _isr(self, pin):
        if self._pin_a.value() == self._pin_b.value():
            self._count += 1
        else:
            self._count -= 1

    @property
    def count(self):
        return self._count

    def reset(self):
        self._count = 0

    def get_and_reset(self):
        """Lấy delta count rồi reset – dùng cho PID loop"""
        c = self._count
        self._count = 0
        return c

    def velocity_rads(self, delta_count, dt):
        """Tính rad/s từ delta xung và thời gian dt (s)"""
        if dt <= 0:
            return 0.0
        return (delta_count / config.ENCODER_CPR) * 6.28318 / dt


encoder_left  = Encoder(config.ENC_LEFT_A,  config.ENC_LEFT_B,  "L")
encoder_right = Encoder(config.ENC_RIGHT_A, config.ENC_RIGHT_B, "R")