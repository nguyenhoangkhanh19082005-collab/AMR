# ============================================================
# config.py – ESP32 AMR Firmware
# Kiến trúc: ESP32 → UART → Pi Zero 2W → WiFi → Server
# Không có HC-SR04, không WiFi trực tiếp lên server
# ============================================================

# ── UART giao tiếp với Pi Zero 2W ───────────────────────────
UART_TX       = 1          # GPIO1  – TX sang Pi RX
UART_RX       = 3          # GPIO3  – RX từ Pi TX
UART_BAUD     = 115200

# ── PIN ENCODER TRÁI ────────────────────────────────────────
ENC_LEFT_A    = 32
ENC_LEFT_B    = 33

# ── PIN ENCODER PHẢI ────────────────────────────────────────
ENC_RIGHT_A   = 34         # INPUT ONLY
ENC_RIGHT_B   = 35         # INPUT ONLY

# ── PIN MOTOR DRIVER TB6612FNG ───────────────────────────────
AIN1          = 18         # Motor A (Trái) direction 1
AIN2          = 19         # Motor A (Trái) direction 2
PWMA          = 25         # Motor A PWM

BIN1          = 12         # Motor B (Phải) direction 1
BIN2          = 13         # Motor B (Phải) direction 2
PWMB          = 26         # Motor B PWM

STBY          = 27         # Driver enable

# ── PIN I2C – MPU9250 ────────────────────────────────────────
I2C_SDA       = 21
I2C_SCL       = 22
MPU_ADDR      = 0x68

# ── THÔNG SỐ CƠ KHÍ ─────────────────────────────────────────
WHEEL_RADIUS  = 0.033      # m
WHEEL_BASE    = 0.17       # m
ENCODER_CPR   = 1000       # xung/vòng – cập nhật sau khi đo

# ── PID ─────────────────────────────────────────────────────
PID_KP        = 0.8
PID_KI        = 0.5
PID_KD        = 0.05

# ── TẦN SỐ ──────────────────────────────────────────────────
CONTROL_HZ    = 100        # Hz – vòng PID + đọc cảm biến
UART_TX_HZ    = 50         # Hz – gửi dữ liệu sang Pi

# ── BATTERY ADC ──────────────────────────────────────────────
BAT_ADC_PIN   = 36         # VP
BAT_DIVIDER   = 1.0        # Hệ số chia áp