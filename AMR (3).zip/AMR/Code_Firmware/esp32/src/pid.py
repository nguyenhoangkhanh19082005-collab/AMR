# ============================================================
# pid.py – PID Controller tốc độ bánh
# ============================================================

import time
import config

class PID:
    def __init__(self, kp=None, ki=None, kd=None,
                 out_min=-100.0, out_max=100.0):
        self.kp = kp or config.PID_KP
        self.ki = ki or config.PID_KI
        self.kd = kd or config.PID_KD
        self.out_min = out_min
        self.out_max = out_max
        self._intg = 0.0
        self._prev = 0.0
        self._t    = time.ticks_ms()

    def compute(self, sp, meas):
        now = time.ticks_ms()
        dt  = max(time.ticks_diff(now, self._t) / 1000.0, 0.001)
        self._t = now
        if dt > 0.5: dt = 0.01

        e = sp - meas
        self._intg = max(-50, min(50, self._intg + e * dt))
        d = (e - self._prev) / dt
        self._prev = e
        out = self.kp*e + self.ki*self._intg + self.kd*d
        return max(self.out_min, min(self.out_max, out))

    def reset(self):
        self._intg = 0.0; self._prev = 0.0
        self._t = time.ticks_ms()

    def tune(self, kp, ki, kd):
        self.kp=kp; self.ki=ki; self.kd=kd; self.reset()


pid_left  = PID()
pid_right = PID()