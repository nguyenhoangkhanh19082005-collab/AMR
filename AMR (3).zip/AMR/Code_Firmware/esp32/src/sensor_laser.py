# sensor_laser.py — ESP32 + TCA9548A + 8x VL53L0X
# Driver dùng: kapetan/MicroPython_VL53L0X (đã test với ESP32)
# Đặt file này và vl53l0x.py vào thư mục gốc ESP32

from machine import I2C, Pin
import vl53l0x
import config

# ── Cấu hình ────────────────────────────────────────
TCA_ADDR = 0x70   # A0=A1=A2=GND

DIRECTIONS   = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW']
MOUNT_ANGLES = [90,   45,   0,  -45, -90, -135, 180,  135]
OFFSETS = [
    (   0,  110),  # S1 N
    (  78,   78),  # S2 NE
    ( 110,    0),  # S3 E
    (  78,  -78),  # S4 SE
    (   0, -110),  # S5 S
    ( -78,  -78),  # S6 SW
    (-110,    0),  # S7 W
    ( -78,   78),  # S8 NW
]

class LaserArray:
    def __init__(self, i2c=None):
        """
        Nhận I2C instance từ ngoài để dùng chung với MPU9250.
        Nếu không truyền vào thì tự tạo (fallback).
        """
        if i2c is not None:
            self.i2c = i2c
        else:
            # Fallback: tự tạo – chỉ dùng khi test độc lập
            self.i2c = I2C(0,
                           sda=Pin(config.I2C_SDA),
                           scl=Pin(config.I2C_SCL),
                           freq=400000)
        self.sensors = []
        self._init_sensors()

    def _select(self, ch):
        """Kích hoạt kênh ch (0-7) trên TCA9548A"""
        self.i2c.writeto(TCA_ADDR, bytes([1 << ch]))

    def _deselect(self):
        self.i2c.writeto(TCA_ADDR, bytes([0]))

    def _init_sensors(self):
        print("[LASER] Khởi tạo 8x VL53L0X...")
        for ch in range(8):
            self._select(ch)
            try:
                tof = vl53l0x.VL53L0X(self.i2c)
                # property setter — không phải method
                tof.measurement_timing_budget = 20000  # 20ms (microseconds)
                tof.start_continuous()
                self.sensors.append(tof)
                print(f"  ✓ Ch{ch} ({DIRECTIONS[ch]}) OK")
            except Exception as e:
                self.sensors.append(None)
                print(f"  ✗ Ch{ch} ({DIRECTIONS[ch]}) FAIL: {e}")
        self._deselect()
        print("[LASER] Khởi tạo xong.")

    def read_all(self):
        """
        Trả về list 8 giá trị [N, NE, E, SE, S, SW, W, NW] tính bằng mm.
        9999 = không có vật cản hoặc lỗi đọc.
        """
        result = []
        for ch, tof in enumerate(self.sensors):
            self._select(ch)
            if tof is not None:
                try:
                    d = tof.read_range_continuous_millimeters()
                    # 8190 là giá trị "out of range" của VL53L0X
                    result.append(d if d < 8190 else 9999)
                except:
                    result.append(9999)
            else:
                result.append(9999)
        self._deselect()
        return result  # [N, NE, E, SE, S, SW, W, NW]
