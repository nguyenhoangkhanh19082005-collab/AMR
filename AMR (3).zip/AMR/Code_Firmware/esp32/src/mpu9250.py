# ============================================================
# mpu9250.py – Driver MPU9250 (Accel + Gyro + Mag)
# ============================================================

from machine import I2C, Pin
import struct, time
import config

_PWR_MGMT_1   = 0x6B
_ACCEL_XOUT_H = 0x3B
_WHO_AM_I     = 0x75
_INT_PIN_CFG  = 0x37
_GYRO_CONFIG  = 0x1B
_ACCEL_CONFIG = 0x1C
_SMPLRT_DIV   = 0x19
_CONFIG_REG   = 0x1A

_AK8963_ADDR  = 0x0C
_AK8963_CNTL1 = 0x0A
_AK8963_ST1   = 0x02
_AK8963_HXL   = 0x03
_AK8963_ST2   = 0x09
_AK8963_ASAX  = 0x10

_ACCEL_SCALE  = 16384.0
_GYRO_SCALE   = 131.0
_MAG_SCALE    = 0.15

class MPU9250:
    def __init__(self):
        self.i2c  = I2C(0,
                        sda=Pin(config.I2C_SDA),
                        scl=Pin(config.I2C_SCL),
                        freq=400000)
        self.addr = config.MPU_ADDR
        self.gyro_offset  = [0.0, 0.0, 0.0]
        self.accel_offset = [0.0, 0.0, 0.0]
        self._mag_asa     = [1.0, 1.0, 1.0]
        self._has_mag     = False
        self._init_mpu()
        self._init_ak8963()

    def _wr(self, reg, val):
        self.i2c.writeto_mem(self.addr, reg, bytes([val]))

    def _rd(self, reg, n):
        return self.i2c.readfrom_mem(self.addr, reg, n)

    def _init_mpu(self):
        who = self._rd(_WHO_AM_I, 1)[0]
        if who not in (0x71, 0x73, 0x70):
            raise OSError(f"MPU9250 không tìm thấy! WHO_AM_I=0x{who:02X}")
        self._wr(_PWR_MGMT_1, 0x80)   # Reset
        time.sleep_ms(100)
        self._wr(_PWR_MGMT_1, 0x01)   # Clock PLL
        time.sleep_ms(10)
        self._wr(_SMPLRT_DIV,   0x04) # 200Hz
        self._wr(_CONFIG_REG,   0x03) # DLPF 41Hz
        self._wr(_GYRO_CONFIG,  0x00) # ±250°/s
        self._wr(_ACCEL_CONFIG, 0x00) # ±2g
        print(f"[IMU] MPU9250 OK (0x{who:02X})")

    def _wr_mag(self, reg, val):
        self.i2c.writeto_mem(_AK8963_ADDR, reg, bytes([val]))

    def _rd_mag(self, reg, n):
        return self.i2c.readfrom_mem(_AK8963_ADDR, reg, n)

    def _init_ak8963(self):
        self._wr(_INT_PIN_CFG, 0x02)  # Bypass I2C
        time.sleep_ms(10)
        try:
            wia = self._rd_mag(0x00, 1)[0]
            if wia != 0x48:
                print(f"[IMU] AK8963 WIA=0x{wia:02X}, bỏ qua mag")
                return
            self._wr_mag(_AK8963_CNTL1, 0x0F)  # Fuse ROM
            time.sleep_ms(10)
            asa = self._rd_mag(_AK8963_ASAX, 3)
            self._mag_asa = [(asa[i]-128)/256.0+1.0 for i in range(3)]
            self._wr_mag(_AK8963_CNTL1, 0x00)
            time.sleep_ms(10)
            self._wr_mag(_AK8963_CNTL1, 0x16)  # 100Hz 16-bit
            time.sleep_ms(10)
            self._has_mag = True
            print("[IMU] AK8963 OK")
        except Exception as e:
            print(f"[IMU] AK8963 lỗi: {e}")

    def read(self):
        data = self._rd(_ACCEL_XOUT_H, 14)
        v    = struct.unpack('>7h', data)

        ax = v[0]/_ACCEL_SCALE - self.accel_offset[0]
        ay = v[1]/_ACCEL_SCALE - self.accel_offset[1]
        az = v[2]/_ACCEL_SCALE - self.accel_offset[2]
        temp = v[3]/333.87 + 21.0
        gx = v[4]/_GYRO_SCALE - self.gyro_offset[0]
        gy = v[5]/_GYRO_SCALE - self.gyro_offset[1]
        gz = v[6]/_GYRO_SCALE - self.gyro_offset[2]

        mx = my = mz = 0.0
        if self._has_mag:
            try:
                st1 = self._rd_mag(_AK8963_ST1, 1)[0]
                if st1 & 0x01:
                    md = self._rd_mag(_AK8963_HXL, 7)
                    if not (md[6] & 0x08):
                        mr = struct.unpack('<3h', md[:6])
                        mx = mr[0]*_MAG_SCALE*self._mag_asa[0]
                        my = mr[1]*_MAG_SCALE*self._mag_asa[1]
                        mz = mr[2]*_MAG_SCALE*self._mag_asa[2]
            except:
                pass

        return {
            "ax": round(ax,4), "ay": round(ay,4), "az": round(az,4),
            "gx": round(gx,4), "gy": round(gy,4), "gz": round(gz,4),
            "mx": round(mx,2), "my": round(my,2), "mz": round(mz,2),
            "tp": round(temp,1)
        }

    def calibrate(self, samples=500):
        print("[IMU] Hiệu chỉnh – đặt robot NẰM PHẲNG, ĐỨNG YÊN...")
        time.sleep(2)
        ax=ay=az=gx=gy=gz = 0.0
        for _ in range(samples):
            d = self._rd(_ACCEL_XOUT_H, 14)
            v = struct.unpack('>7h', d)
            ax+=v[0]; ay+=v[1]; az+=v[2]
            gx+=v[4]; gy+=v[5]; gz+=v[6]
            time.sleep_ms(4)
        n = samples
        self.accel_offset = [ax/n/_ACCEL_SCALE,
                             ay/n/_ACCEL_SCALE,
                             az/n/_ACCEL_SCALE - 1.0]
        self.gyro_offset  = [gx/n/_GYRO_SCALE,
                             gy/n/_GYRO_SCALE,
                             gz/n/_GYRO_SCALE]
        print("[IMU] Offset gyro :", [round(v,5) for v in self.gyro_offset])
        print("[IMU] Offset accel:", [round(v,5) for v in self.accel_offset])


imu = MPU9250()