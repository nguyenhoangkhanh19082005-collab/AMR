# test_encoder.py
# Muc dich: Xac nhan encoder doc dung xung, dung chieu
# Chay: mpremote connect COM8 run tests/test_encoder.py
# Thao tac: Quay banh tay trong khi script dang chay

from machine import Pin
import time

# ---- Pin config ----
ENC_L_A = 32
ENC_L_B = 33
ENC_R_A = 34  # input-only pin
ENC_R_B = 35  # input-only pin

# ---- Bien dem ----
count_l = 0
count_r = 0

# ---- Interrupt handlers ----
def isr_left(pin):
    global count_l
    if Pin(ENC_L_B).value() == 0:
        count_l += 1
    else:
        count_l -= 1

def isr_right(pin):
    global count_r
    if Pin(ENC_R_B).value() == 0:
        count_r += 1
    else:
        count_r -= 1

# ---- Khoi tao ----
pin_la = Pin(ENC_L_A, Pin.IN, Pin.PULL_UP)
pin_lb = Pin(ENC_L_B, Pin.IN, Pin.PULL_UP)
pin_ra = Pin(ENC_R_A, Pin.IN, Pin.PULL_UP)
pin_rb = Pin(ENC_R_B, Pin.IN, Pin.PULL_UP)

pin_la.irq(trigger=Pin.IRQ_RISING, handler=isr_left)
pin_ra.irq(trigger=Pin.IRQ_RISING, handler=isr_right)

# ======== CHAY TEST ========
print("="*40)
print("TEST ENCODER")
print("Quay banh TRAI hoac PHAI bang tay")
print("Ctrl+C de dung")
print("="*40)

try:
    while True:
        print(f"LEFT: {count_l:6d}  |  RIGHT: {count_r:6d}", end="\r")
        time.sleep(0.1)
except KeyboardInterrupt:
    print(f"\n\nKet qua cuoi:")
    print(f"  Encoder TRAI : {count_l} xung")
    print(f"  Encoder PHAI : {count_r} xung")
    print("Test encoder hoan tat!")