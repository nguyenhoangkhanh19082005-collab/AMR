# test_imu.py
# Muc dich: Xac nhan MPU9250 doc dung Accel + Gyro
# Chay: mpremote connect COM8 run tests/test_imu.py
# Robot phai dat BANG PHANG, DUNG YEN khi chay

from machine import I2C, Pin
import time, struct

I2C_SDA = 21
I2C_SCL = 22
MPU_ADDR = 0x68

i2c = I2C(0, sda=Pin(I2C_SDA), scl=Pin(I2C_SCL), freq=400000)

# ---- Quet I2C bus truoc ----
print("Quet I2C bus...")
devices = i2c.scan()
print(f"Thiet bi tim thay: {[hex(d) for d in devices]}")

if MPU_ADDR not in devices:
    print(f"KHONG thay MPU9250 tai 0x{MPU_ADDR:02X}!")
    print("Kiem tra lai day noi GPIO21/22 va dien tro pull-up.")
    raise SystemExit

print(f"MPU9250 tim thay tai 0x{MPU_ADDR:02X} ✓")

# ---- Wake up MPU9250 ----
i2c.writeto_mem(MPU_ADDR, 0x6B, b'\x00')  # Clear sleep bit
time.sleep(0.1)

# ---- Doc WHO_AM_I ----
who = i2c.readfrom_mem(MPU_ADDR, 0x75, 1)[0]
print(f"WHO_AM_I = 0x{who:02X}  (mong doi: 0x71 hoac 0x73)")

def read_raw():
    raw = i2c.readfrom_mem(MPU_ADDR, 0x3B, 14)
    vals = struct.unpack('>7h', raw)
    ax = vals[0] / 16384.0 * 9.81
    ay = vals[1] / 16384.0 * 9.81
    az = vals[2] / 16384.0 * 9.81
    gx = vals[4] / 131.0
    gy = vals[5] / 131.0
    gz = vals[6] / 131.0
    return ax, ay, az, gx, gy, gz

# ======== CHAY TEST ========
print("\n" + "="*50)
print("Doc IMU - 5 giay (dat robot bang phang, dung yen)")
print("="*50)
print(f"{'Ax':>8} {'Ay':>8} {'Az':>8}  |  {'Gx':>8} {'Gy':>8} {'Gz':>8}")
print("-"*50)

try:
    for i in range(50):  # 50 lan x 0.1s = 5 giay
        ax, ay, az, gx, gy, gz = read_raw()
        print(f"{ax:8.3f} {ay:8.3f} {az:8.3f}  |  {gx:8.3f} {gy:8.3f} {gz:8.3f}")
        time.sleep(0.1)
except KeyboardInterrupt:
    pass

print("\nKiem tra:")
print("  Az ~ 9.8 m/s2 khi dat nam ngang => Accel OK")
print("  Gx/Gy/Gz ~ 0.0 khi dung yen     => Gyro OK")
print("Test IMU hoan tat!")