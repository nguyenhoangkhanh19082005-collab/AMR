# test_motor.py
# Muc dich: Test TB6612FNG + 2 motor DC
# Chay: mpremote connect COM8 run tests/test_motor.py
# LUU Y: Nhat robot len khoi mat dat truoc khi chay!

import time
from machine import Pin, PWM

# ---- Pin config (khop voi config.py) ----
PWMA  = 25
PWMB  = 26
AIN1  = 18
AIN2  = 19
BIN1  = 12
BIN2  = 13
STBY  = 27

# ---- Khoi tao ----
stby  = Pin(STBY, Pin.OUT)
ain1  = Pin(AIN1, Pin.OUT)
ain2  = Pin(AIN2, Pin.OUT)
bin1  = Pin(BIN1, Pin.OUT)
bin2  = Pin(BIN2, Pin.OUT)
pwma  = PWM(Pin(PWMA), freq=20000)
pwmb  = PWM(Pin(PWMB), freq=20000)

def duty(percent):
    """Chuyen % (0-100) sang duty cycle 0-1023"""
    return int(percent / 100 * 1023)

def stop():
    pwma.duty(0)
    pwmb.duty(0)
    ain1.value(0); ain2.value(0)
    bin1.value(0); bin2.value(0)
    stby.value(0)
    print("  >> STOP")

def motor_left(speed_pct):
    """speed_pct: -100 den 100. Duong=tien, Am=lui"""
    stby.value(1)
    if speed_pct >= 0:
        ain1.value(1); ain2.value(0)
    else:
        ain1.value(0); ain2.value(1)
        speed_pct = -speed_pct
    pwma.duty(duty(speed_pct))

def motor_right(speed_pct):
    stby.value(1)
    if speed_pct >= 0:
        bin1.value(1); bin2.value(0)
    else:
        bin1.value(0); bin2.value(1)
        speed_pct = -speed_pct
    pwmb.duty(duty(speed_pct))

# ======== CHAY TEST ========
print("="*40)
print("TEST MOTOR - Nhat xe len truoc khi chay!")
print("="*40)
time.sleep(2)  # cho ban chuan bi

print("\n[1] Motor TRAI tien 40% - 2 giay")
motor_left(40)
time.sleep(2)
stop(); time.sleep(1)

print("\n[2] Motor PHAI tien 40% - 2 giay")
motor_right(40)
time.sleep(2)
stop(); time.sleep(1)

print("\n[3] CA HAI tien 50% - 3 giay")
motor_left(50); motor_right(50)
time.sleep(3)
stop(); time.sleep(1)

print("\n[4] CA HAI lui 40% - 2 giay")
motor_left(-40); motor_right(-40)
time.sleep(2)
stop(); time.sleep(1)

print("\n[5] Quay tai cho (trai tien, phai lui) - 2 giay")
motor_left(40); motor_right(-40)
time.sleep(2)
stop(); time.sleep(1)

print("\n[6] Tang toc dan tu 20% -> 80% -> dung")
for spd in range(20, 81, 10):
    print(f"  Speed: {spd}%")
    motor_left(spd); motor_right(spd)
    time.sleep(0.4)
stop()

print("\n[DONE] Test motor hoan tat!")