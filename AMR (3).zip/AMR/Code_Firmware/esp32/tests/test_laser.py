# test_laser.py — Chạy thử 8 sensor VL53L0X
# Dùng: mpremote connect COM8 run test_laser.py

from sensor_laser import LaserArray, DIRECTIONS
import utime

print("=" * 40)
print("TEST: 8x VL53L0X qua TCA9548A")
print("=" * 40)

laser = LaserArray()
print()

for i in range(10):
    readings = laser.read_all()
    print(f"--- Lần {i+1} ---")
    for ch, (val, direction) in enumerate(zip(readings, DIRECTIONS)):
        bar = "█" * min(val // 100, 20) if val < 9999 else "---"
        status = f"{val:4d}mm  {bar}" if val < 9999 else " OUT OF RANGE"
        print(f"  S{ch+1} {direction:2s}: {status}")
    print()
    utime.sleep_ms(500)

print("Test hoàn tất.")
