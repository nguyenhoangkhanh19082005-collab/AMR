@echo off
echo ========================================
echo     Upload ESP32 Firmware
echo ========================================

REM Sua thanh cong COM thuc te cua ban
set PORT=COM8

REM Tu dong lay duong dan chinh xac theo vi tri file bat
set SRC=%~dp0..\esp32\src

echo Uploading to %PORT%...
mpremote connect %PORT% cp %SRC%\config.py    :config.py
mpremote connect %PORT% cp %SRC%\encoder.py   :encoder.py
mpremote connect %PORT% cp %SRC%\main.py      :main.py
mpremote connect %PORT% cp %SRC%\motor.py     :motor.py
mpremote connect %PORT% cp %SRC%\mpu9250.py   :mpu9250.py
mpremote connect %PORT% cp %SRC%\pid.py       :pid.py
mpremote connect %PORT% cp %SRC%\uart_comm.py :uart_comm.py

echo.
echo Verifying files on ESP32:
mpremote connect %PORT% ls

echo.
echo Done! Resetting ESP32...
mpremote connect %PORT% reset