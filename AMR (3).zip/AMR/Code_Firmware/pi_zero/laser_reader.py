# ============================================================
# laser_reader.py – Đọc 8x VL53L0X từ ESP32 qua UART
# Thay thế lidar_reader.py (RPLIDAR A2M8 đã bị loại bỏ)
#
# VL53L0X được đọc bởi ESP32 → gửi lên Pi trong packet UART
# Pi chỉ cần extract field "lsr" từ packet ESP32
# Layout: N, NE, E, SE, S, SW, W, NW (8 hướng, R=110mm)
# ============================================================

import threading, time

DIRECTIONS = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"]

class LaserReader:
    """
    Không đọc hardware trực tiếp – extract dữ liệu VL53L0X
    từ packet ESP32 đã được ESP32Reader parse sẵn.
    Dùng: laser_reader.update(esp_data) trong main loop
    """
    def __init__(self):
        self._latest    = None
        self._lock      = threading.Lock()
        self._count     = 0

    def update(self, esp_data: dict):
        """
        Gọi từ main loop mỗi khi có packet ESP32 mới.
        Extract field 'lsr' (8 giá trị mm từ VL53L0X).
        """
        raw = esp_data.get("lsr")
        if raw is None:
            return

        # raw = {"N": 412, "NE": 350, ..., "NW": 500} (mm)
        # Hoặc list [N, NE, E, SE, S, SW, W, NW]
        if isinstance(raw, list) and len(raw) == 8:
            distances = {d: raw[i] for i, d in enumerate(DIRECTIONS)}
        elif isinstance(raw, dict):
            distances = {d: raw.get(d, -1) for d in DIRECTIONS}
        else:
            return

        scan = {
            "distances_mm": distances,     # {"N": 412, "NE": 350, ...}
            "t": esp_data.get("t", time.time())
        }

        with self._lock:
            self._latest = scan
        self._count += 1

    def get_latest(self):
        with self._lock:
            return self._latest

    def scan_count(self):
        return self._count


laser_reader = LaserReader()
