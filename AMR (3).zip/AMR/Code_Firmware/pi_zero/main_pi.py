# ============================================================
# main_pi.py – Pi Zero 2W Main
# Nhận UART ESP32 (telemetry + laser VL53L0X) → gửi Server TCP
# Nhận lệnh Server → inject "mode" → forward ESP32
# ============================================================

import time, threading
import pi_config
from esp32_reader import esp32
from laser_reader import laser_reader
from server_bridge import bridge

TELE_HZ     = pi_config.TELEMETRY_HZ
TELE_PERIOD = 1.0 / TELE_HZ

# Mapping: ESP32 DIRECTIONS [N,NE,E,SE,S,SW,W,NW] (index 0-7)
# → Server LASER_ANGLES [0°,45°,90°,135°,180°,225°,270°,315°]
# Server angle 0°=E → index 2 | 45°=NE → 1 | 90°=N → 0
# 135°=NW → 7 | 180°=W → 6 | 225°=SW → 5 | 270°=S → 4 | 315°=SE → 3
_LASER_IDX = [2, 1, 0, 7, 6, 5, 4, 3]   # remap ESP32 list → server order


def build_packet(esp_data, laser_data, seq):
    """
    Đóng gói 1 packet gộp theo đúng format server expect:
    {ts, enc:{l,r}, imu:{gz,ax,ay}, laser:[8 giá trị mm], bat}
    """
    enc = esp_data.get("enc", {"l": 0, "r": 0})
    imu = esp_data.get("imu", {})

    # Remap laser dict → flat list theo thứ tự LASER_ANGLES server
    if laser_data is not None:
        raw = laser_data["distances_mm"]   # {"N":mm, "NE":mm, ...}
        dirs = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"]
        esp32_list = [raw.get(d, -1) for d in dirs]
        laser_flat = [esp32_list[i] for i in _LASER_IDX]
    else:
        laser_flat = [-1] * 8

    return {
        "ts"   : esp_data.get("t", time.time()),
        "seq"  : seq,
        "enc"  : {
            "l": enc.get("l", 0),
            "r": enc.get("r", 0)
        },
        "imu"  : {
            "gz": imu.get("gz", 0.0),
            "ax": imu.get("ax", 0.0),
            "ay": imu.get("ay", 0.0)
        },
        "laser": laser_flat,
        "bat"  : esp_data.get("bat", 0.0)
    }


def inject_mode(cmd: dict) -> dict:
    """
    Server gửi {"v":..., "w":...} nhưng ESP32 expect {"mode":"velocity","v":...,"w":...}
    Pi inject field "mode" trước khi forward xuống ESP32.
    """
    if "v" in cmd and "w" in cmd and "mode" not in cmd:
        cmd = dict(cmd)
        cmd["mode"] = "velocity"
    return cmd


def stats_loop():
    while True:
        time.sleep(10)
        esp_s = esp32.stats()
        br_s  = bridge.stats()
        print(f"[Stats] ESP32 rx={esp_s['rx']} err={esp_s['err']} | "
              f"Laser scans={laser_reader.scan_count()} | "
              f"Server tx={br_s['tx']} rx={br_s['rx']}")


def main():
    print("=" * 45)
    print("  AMR Pi Zero 2W – Bridge Node")
    print("=" * 45)

    esp32.start()
    bridge.start_recv_loop()

    threading.Thread(target=stats_loop, daemon=True).start()

    print(f"[Main] Gửi packet gộp {TELE_HZ}Hz → {pi_config.SERVER_IP}:{pi_config.SERVER_PORT}")
    print("[Main] Bắt đầu vòng lặp chính...")

    seq      = 0
    last_tx  = time.time()
    last_esp = None

    while True:
        now = time.time()

        # Lấy dữ liệu ESP32 mới nhất
        esp_data = esp32.get_latest()
        if esp_data is not None:
            last_esp = esp_data
            laser_reader.update(esp_data)   # extract field "lsr"

        # Nhận lệnh từ server → inject mode → forward ESP32
        cmd = bridge.get_cmd()
        if cmd is not None:
            cmd = inject_mode(cmd)
            esp32.send_cmd(cmd)

        # Gửi packet gộp lên server (20Hz)
        if now - last_tx >= TELE_PERIOD:
            last_tx = now
            if last_esp is not None:
                seq += 1
                laser = laser_reader.get_latest()
                pkt = build_packet(last_esp, laser, seq)
                bridge.send_telemetry(pkt)

        time.sleep(0.001)


if __name__ == "__main__":
    main()
