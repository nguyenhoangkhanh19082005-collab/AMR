# ============================================================
# pi_config.py – Pi Zero 2W Bridge Configuration
# ============================================================

# ── UART nhận từ ESP32 ───────────────────────────────────────
ESP32_UART_PORT  = "/dev/ttyAMA0"   # hoặc /dev/ttyS0
ESP32_UART_BAUD  = 115200

# ── VL53L0X Laser Sensors (8 cảm biến ToF qua I2C) ──────────
# (Không cần port riêng – đọc trực tiếp trên ESP32 qua UART)

# ── Server Laptop ────────────────────────────────────────────
SERVER_IP        = "192.168.110.210"  # ← Đổi thành IP laptop
SERVER_PORT      = 5000               # TCP duy nhất: telemetry + laser + cmd

# ── Tần số ──────────────────────────────────────────────────
TELEMETRY_HZ     = 20               # Hz gửi telemetry lên server
