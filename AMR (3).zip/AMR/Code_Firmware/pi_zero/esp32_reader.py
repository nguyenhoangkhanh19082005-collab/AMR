# ============================================================
# esp32_reader.py – Đọc UART từ ESP32, parse JSON
# ============================================================

import serial, json, threading, time
import pi_config

class ESP32Reader:
    def __init__(self):
        self.ser = serial.Serial(
            port     = pi_config.ESP32_UART_PORT,
            baudrate = pi_config.ESP32_UART_BAUD,
            timeout  = 1
        )
        self._latest  = None
        self._lock    = threading.Lock()
        self._running = False
        self._rx_count = 0
        self._err_count = 0

    def start(self):
        self._running = True
        t = threading.Thread(target=self._loop, daemon=True)
        t.start()
        print(f"[ESP32] Đọc UART tại {pi_config.ESP32_UART_PORT}")

    def _loop(self):
        while self._running:
            try:
                raw = self.ser.readline()
                if not raw:
                    continue
                data = json.loads(raw.decode("utf-8", errors="ignore").strip())
                with self._lock:
                    self._latest = data
                self._rx_count += 1
            except json.JSONDecodeError:
                self._err_count += 1
            except Exception as e:
                print(f"[ESP32] Lỗi UART: {e}")
                time.sleep(0.1)

    def get_latest(self):
        with self._lock:
            return self._latest

    def send_cmd(self, cmd_dict):
        """Gửi lệnh xuống ESP32 qua UART"""
        try:
            self.ser.write((json.dumps(cmd_dict) + "\n").encode())
        except Exception as e:
            print(f"[ESP32] Lỗi gửi lệnh: {e}")

    def stats(self):
        return {"rx": self._rx_count, "err": self._err_count}

    def stop(self):
        self._running = False
        self.ser.close()


esp32 = ESP32Reader()