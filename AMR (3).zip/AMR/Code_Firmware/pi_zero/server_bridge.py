# ============================================================
# server_bridge.py – TCP bridge Pi ↔ Server
# Gửi: telemetry + laser scan lên Server qua TCP
# Nhận: lệnh từ Server → forward xuống ESP32
# ============================================================

import socket, json, threading, time
import pi_config

class ServerBridge:
    def __init__(self):
        self._sock       = None
        self._lock_tx    = threading.Lock()
        self._lock_cmd   = threading.Lock()
        self._latest_cmd = None
        self._tx_count   = 0
        self._rx_count   = 0
        self._connected  = False

    # ── Kết nối TCP ─────────────────────────────────────────
    def _connect(self):
        while True:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(5)
                sock.connect((pi_config.SERVER_IP, pi_config.SERVER_PORT))
                sock.settimeout(None)
                self._sock = sock
                self._connected = True
                print(f"[Bridge] TCP kết nối tới {pi_config.SERVER_IP}:{pi_config.SERVER_PORT}")
                return
            except Exception as e:
                print(f"[Bridge] Kết nối thất bại: {e} – thử lại sau 2s...")
                time.sleep(2)

    def start_recv_loop(self):
        self._connect()
        t = threading.Thread(target=self._recv_loop, daemon=True)
        t.start()
        print(f"[Bridge] Bắt đầu nhận lệnh từ server")

    # ── Nhận lệnh từ server (chạy trong thread riêng) ───────
    def _recv_loop(self):
        buf = ""
        while True:
            try:
                chunk = self._sock.recv(1024).decode("utf-8", errors="ignore")
                if not chunk:
                    raise ConnectionResetError("Server đóng kết nối")
                buf += chunk
                while "\n" in buf:
                    line, buf = buf.split("\n", 1)
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        cmd = json.loads(line)
                        with self._lock_cmd:
                            self._latest_cmd = cmd
                        self._rx_count += 1
                    except json.JSONDecodeError:
                        print(f"[Bridge] JSON lỗi: {line}")
            except Exception as e:
                print(f"[Bridge] Mất kết nối: {e} – đang reconnect...")
                self._connected = False
                self._connect()
                buf = ""

    # ── Gửi packet qua TCP ──────────────────────────────────
    def _send(self, packet: dict):
        payload = (json.dumps(packet) + "\n").encode()
        with self._lock_tx:
            try:
                self._sock.sendall(payload)
                self._tx_count += 1
            except Exception as e:
                print(f"[Bridge] Lỗi gửi: {e}")
                # Reconnect sẽ được xử lý bởi _recv_loop

    def send_telemetry(self, packet):
        self._send(packet)

    def send_laser(self, laser_packet):
        self._send(laser_packet)

    def get_cmd(self):
        with self._lock_cmd:
            cmd = self._latest_cmd
            self._latest_cmd = None
            return cmd

    def stats(self):
        return {"tx": self._tx_count, "rx": self._rx_count}


bridge = ServerBridge()
